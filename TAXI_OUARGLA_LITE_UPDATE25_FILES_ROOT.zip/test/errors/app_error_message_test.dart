import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/errors/app_error_message.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  group('AppErrorMessage', () {
    test('maps network errors without exposing technical details', () {
      expect(
        AppErrorMessage.from(const SocketException('private host detail')),
        contains('اتصال الإنترنت'),
      );
      expect(
        AppErrorMessage.from(const SocketException('private host detail')),
        isNot(contains('private host detail')),
      );
    });

    test('maps common database permission and uniqueness errors', () {
      expect(
        AppErrorMessage.from(const PostgrestException(message: 'secret', code: '42501')),
        contains('صلاحية'),
      );
      expect(
        AppErrorMessage.from(const PostgrestException(message: 'secret', code: '23505')),
        contains('موجود مسبقاً'),
      );
    });

    test('maps invalid input and unknown errors safely', () {
      expect(AppErrorMessage.from(ArgumentError('secret')), contains('البيانات المدخلة'));
      expect(AppErrorMessage.from(StateError('secret')), isNot(contains('secret')));
    });
  });
}
