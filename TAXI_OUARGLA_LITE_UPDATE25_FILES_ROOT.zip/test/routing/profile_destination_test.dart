import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/models/user_profile.dart';
import 'package:taxi_ouargla_lite/routing/profile_destination.dart';

void main() {
  UserProfile profile(String role, {bool verified = false}) => UserProfile(
        id: 'user-1',
        role: role,
        isVerified: verified,
        isOnline: false,
      );

  group('destinationForProfile', () {
    test('rider routes to rider home', () {
      expect(destinationForProfile(profile('rider')), ProfileDestination.riderHome);
    });

    test('verified driver routes to driver home', () {
      expect(destinationForProfile(profile('driver', verified: true)),
          ProfileDestination.driverHome);
    });

    test('unverified driver routes to pending', () {
      expect(destinationForProfile(profile('driver')),
          ProfileDestination.driverPending);
    });

    test('admin routes to admin home', () {
      expect(destinationForProfile(profile('admin')), ProfileDestination.adminHome);
    });

    test('unsupported role is invalid', () {
      expect(destinationForProfile(profile('superuser')), ProfileDestination.invalid);
    });
  });
}
