import 'package:flutter_test/flutter_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:taxi_ouargla_lite/models/ride_status.dart';
import 'package:taxi_ouargla_lite/services/ride_rpc_client.dart';
import 'package:taxi_ouargla_lite/services/ride_service.dart';

class _FakeRpc implements RideRpcClient {
  _FakeRpc(this.currentUserId);
  @override
  String? currentUserId;
  String? function;
  Map<String, dynamic>? params;
  Object? response = {'id': 'ride-1', 'status': 'searching'};

  @override
  Future<Object?> call(String name, {required Map<String, dynamic> params}) async {
    function = name;
    this.params = params;
    return response;
  }
}

void main() {
  late SupabaseClient client;
  late _FakeRpc rpc;
  late RideService service;

  setUp(() {
    client = SupabaseClient('https://example.supabase.co', 'test-anon-key');
    rpc = _FakeRpc('user-1');
    service = RideService(client: client, rpc: rpc);
  });

  tearDown(() => client.dispose());

  test('createRide calls secure RPC and never sends protected ride fields', () async {
    final result = await service.createRide(
      pickupAddress: 'وسط المدينة', pickupLat: 31.95, pickupLng: 5.32,
      dropoffAddress: 'الرويسات', dropoffLat: 31.96, dropoffLng: 5.34,
    );

    expect(result['id'], 'ride-1');
    expect(rpc.function, 'create_ride_secure');
    expect(rpc.params!.keys, containsAll([
      'p_pickup_address', 'p_pickup_lat', 'p_pickup_lng',
      'p_dropoff_address', 'p_dropoff_lat', 'p_dropoff_lng',
    ]));
    expect(rpc.params!.keys, isNot(contains('status')));
    expect(rpc.params!.keys, isNot(contains('driver_id')));
    expect(rpc.params!.keys, isNot(contains('rider_id')));
  });

  test('rejects invalid coordinates before making an RPC call', () async {
    await expectLater(
      service.createRide(
        pickupAddress: 'انطلاق', pickupLat: 91, pickupLng: 5,
        dropoffAddress: 'وجهة', dropoffLat: 31, dropoffLng: 5,
      ),
      throwsArgumentError,
    );
    expect(rpc.function, isNull);
  });

  test('only allows driver-forward status values', () async {
    await expectLater(service.setRideStatus('ride-1', RideStatus.cancelled), throwsArgumentError);
    expect(rpc.function, isNull);
  });
}
