import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/models/user_profile.dart';

void main() {
  test('parses only a matching, supported profile', () {
    final profile = UserProfile.fromJson({'id':'u1','role':'driver','is_verified':true,'is_online':false}, expectedUserId:'u1');
    expect(profile.role, 'driver');
    expect(profile.isVerified, isTrue);
  });

  test('rejects role escalation and mismatched identity', () {
    final base = {'id':'u1','role':'admin','is_verified':true,'is_online':false};
    expect(() => UserProfile.fromJson(base, expectedUserId:'u1'), returnsNormally);
    expect(() => UserProfile.fromJson({...base, 'id':'u2'}, expectedUserId:'u1'), throwsFormatException);
    expect(() => UserProfile.fromJson({...base, 'role':'superadmin'}, expectedUserId:'u1'), throwsFormatException);
  });
}
