import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/models/ride_status.dart';

void main() {
  test('database status round trips exactly', () {
    for (final status in RideStatus.values) {
      expect(RideStatus.fromDatabase(status.databaseValue), status);
    }
  });

  test('rejects unsupported and legacy statuses', () {
    for (final value in ['en_route', 'SEARCHING', ' searching', 'unknown']) {
      expect(() => RideStatus.fromDatabase(value), throwsFormatException);
    }
  });

  test('active state sets preserve rider/driver distinction', () {
    expect(RideStatus.searching.isActiveForRider, isTrue);
    expect(RideStatus.searching.isActiveForDriver, isFalse);
    for (final status in [RideStatus.accepted, RideStatus.arrived, RideStatus.inProgress]) {
      expect(status.isActiveForRider, isTrue);
      expect(status.isActiveForDriver, isTrue);
    }
    expect(RideStatus.completed.isFinal, isTrue);
    expect(RideStatus.cancelled.isFinal, isTrue);
  });
}
