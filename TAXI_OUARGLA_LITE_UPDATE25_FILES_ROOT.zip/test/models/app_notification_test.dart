import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/models/app_notification.dart';

void main() {
  group('AppNotification', () {
    test('parses a notification and recognizes unread state', () {
      final notification = AppNotification.fromJson({
        'id': '00000000-0000-0000-0000-000000000001',
        'title': 'تم قبول طلبك',
        'body': 'وافق سائق على طلب الرحلة.',
        'event_key': 'ride_accepted',
        'created_at': '2026-11-18T10:30:00Z',
        'ride_id': '00000000-0000-0000-0000-000000000002',
        'read_at': null,
      });

      expect(notification.title, 'تم قبول طلبك');
      expect(notification.eventKey, 'ride_accepted');
      expect(notification.rideId, '00000000-0000-0000-0000-000000000002');
      expect(notification.isRead, isFalse);
    });

    test('recognizes a read notification', () {
      final notification = AppNotification.fromJson({
        'id': '00000000-0000-0000-0000-000000000001',
        'title': 'اكتملت الرحلة',
        'body': 'اكتملت رحلتك.',
        'event_key': 'ride_completed',
        'created_at': '2026-11-18T10:30:00Z',
        'ride_id': null,
        'read_at': '2026-11-18T10:31:00Z',
      });

      expect(notification.isRead, isTrue);
      expect(notification.readAt, isNotNull);
    });
  });
}
