import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/models/ride_model.dart';
import 'package:taxi_ouargla_lite/models/ride_status.dart';

Map<String, dynamic> validRide() => {
  'id': 'ride-1', 'rider_id': 'rider-1', 'driver_id': null,
  'pickup_address': 'وسط ورقلة', 'pickup_lat': 31.95, 'pickup_lng': 5.32,
  'dropoff_address': 'حي النصر', 'dropoff_lat': 31.96, 'dropoff_lng': 5.34,
  'status': 'searching', 'driver_lat': null, 'driver_lng': null,
  'rating': null, 'created_at': '2026-01-01T10:00:00Z',
  'updated_at': '2026-01-01T10:00:00Z',
};

void main() {
  test('parses SQL V2 ride row', () {
    final ride = RideModel.fromJson(validRide());
    expect(ride.status, RideStatus.searching);
    expect(ride.driverId, isNull);
  });

  test('rejects partial driver coordinates and non-finite coordinates', () {
    expect(() => RideModel.fromJson({...validRide(), 'driver_lat': 31.9}), throwsFormatException);
    expect(() => RideModel.fromJson({...validRide(), 'pickup_lat': double.infinity}), throwsFormatException);
  });

  test('creation payload contains only insert-granted fields', () {
    final ride = RideModel.fromJson(validRide());
    final payload = ride.toCreationMap(riderId: 'rider-1');
    expect(payload.keys.toSet(), {
      'rider_id', 'pickup_address', 'pickup_lat', 'pickup_lng',
      'dropoff_address', 'dropoff_lat', 'dropoff_lng',
    });
    expect(payload.containsKey('status'), isFalse);
    expect(payload.containsKey('driver_id'), isFalse);
  });
}
