import 'package:flutter_test/flutter_test.dart';
import 'package:taxi_ouargla_lite/flows/ride_flow_policy.dart';
import 'package:taxi_ouargla_lite/models/ride_model.dart';
import 'package:taxi_ouargla_lite/models/ride_status.dart';

RideModel ride({RideStatus status = RideStatus.searching, String? driverId, int? rating}) => RideModel(
  id: 'ride-1', riderId: 'rider-1', driverId: driverId,
  pickupAddress: 'A', pickupLat: 31.95, pickupLng: 5.32,
  dropoffAddress: 'B', dropoffLat: 31.96, dropoffLng: 5.33,
  status: status, driverLat: null, driverLng: null, rating: rating,
  createdAt: DateTime.utc(2026), updatedAt: DateTime.utc(2026),
);

void main() {
  group('RideFlowPolicy', () {
    test('only owning rider can cancel an unassigned searching ride', () {
      expect(RideFlowPolicy.riderCanCancel(ride(), 'rider-1'), isTrue);
      expect(RideFlowPolicy.riderCanCancel(ride(), 'other'), isFalse);
      expect(RideFlowPolicy.riderCanCancel(ride(status: RideStatus.accepted, driverId: 'driver-1'), 'rider-1'), isFalse);
    });

    test('driver transition sequence is strictly ordered', () {
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.accepted), RideStatus.arrived);
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.arrived), RideStatus.inProgress);
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.inProgress), RideStatus.completed);
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.searching), isNull);
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.completed), isNull);
      expect(RideFlowPolicy.nextDriverStatus(RideStatus.cancelled), isNull);
    });

    test('rating is available only to owning rider after completion and once', () {
      expect(RideFlowPolicy.riderCanRate(ride(status: RideStatus.completed), 'rider-1'), isTrue);
      expect(RideFlowPolicy.riderCanRate(ride(status: RideStatus.completed, rating: 5), 'rider-1'), isFalse);
      expect(RideFlowPolicy.riderCanRate(ride(status: RideStatus.completed), 'other'), isFalse);
    });

    test('driver location requires assigned active ride', () {
      expect(RideFlowPolicy.driverCanShareLocation(ride(status: RideStatus.accepted, driverId: 'driver-1'), 'driver-1'), isTrue);
      expect(RideFlowPolicy.driverCanShareLocation(ride(status: RideStatus.searching), 'driver-1'), isFalse);
      expect(RideFlowPolicy.driverCanShareLocation(ride(status: RideStatus.completed, driverId: 'driver-1'), 'driver-1'), isFalse);
    });

    test('no en_route state exists in the policy', () {
      expect(RideStatus.values.map((e) => e.databaseValue), isNot(contains('en_route')));
    });
  });
}
