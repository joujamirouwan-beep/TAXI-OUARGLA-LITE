import 'dart:async';
import 'dart:io';

import 'package:supabase_flutter/supabase_flutter.dart';

/// Converts technical failures into short, safe Arabic messages for the UI.
/// Do not display raw PostgREST/RPC exception text to end users.
class AppErrorMessage {
  const AppErrorMessage._();

  static String from(Object error) {
    if (error is SocketException || error is HttpException || error is TimeoutException) {
      return 'تعذر الاتصال بالخدمة. تحقق من اتصال الإنترنت ثم حاول مجدداً.';
    }
    if (error is AuthException) {
      return 'تعذر إتمام تسجيل الدخول. تحقق من بيانات الحساب وحاول مجدداً.';
    }
    if (error is PostgrestException) {
      switch (error.code) {
        case '42501':
          return 'ليست لديك صلاحية لتنفيذ هذا الإجراء.';
        case '23505':
          return 'هذا الطلب موجود مسبقاً أو يتعارض مع طلب نشط.';
        case '23503':
          return 'تعذر ربط البيانات المطلوبة. حدّث الصفحة وحاول مجدداً.';
        default:
          return 'تعذر حفظ البيانات حالياً. حاول مرة أخرى لاحقاً.';
      }
    }
    if (error is FormatException) {
      return 'وصلتنا بيانات غير مكتملة أو غير صالحة. أعد تحميل الصفحة.';
    }
    if (error is ArgumentError) {
      return 'راجع البيانات المدخلة ثم حاول مجدداً.';
    }
    return 'حدث خطأ غير متوقع. حاول مرة أخرى، وإذا استمر تواصل مع الدعم.';
  }
}
