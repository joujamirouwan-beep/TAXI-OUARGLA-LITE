import 'package:supabase_flutter/supabase_flutter.dart';

import '../repositories/ride_data_source.dart';
import '../repositories/ride_repository.dart';
import '../services/profile_service.dart';
import '../services/notification_service.dart';
import '../services/ride_service.dart';

/// App-wide dependency container. Initialize once after Supabase.initialize.
class AppDependencies {
  AppDependencies._(this.client) {
    profileService = ProfileService(client);
    notificationService = NotificationService(client);
    rideService = RideService(client: client);
    rideDataSource = SupabaseRideDataSource(client);
    rideRepository = RideRepository(
      service: rideService,
      dataSource: rideDataSource,
    );
  }

  final SupabaseClient client;

  static AppDependencies? _instance;

  late final ProfileService profileService;
  late final NotificationService notificationService;
  late final RideService rideService;
  late final RideDataSource rideDataSource;
  late final RideRepository rideRepository;

  static AppDependencies get instance => _instance ??
      (throw StateError('AppDependencies.initialize must be called first'));

  static AppDependencies initialize(SupabaseClient client) {
    final existing = _instance;
    if (existing != null) {
      if (!identical(existing.client, client)) {
        throw StateError(
          'AppDependencies was already initialized with a different SupabaseClient',
        );
      }
      return existing;
    }
    return _instance = AppDependencies._(client);
  }
}
