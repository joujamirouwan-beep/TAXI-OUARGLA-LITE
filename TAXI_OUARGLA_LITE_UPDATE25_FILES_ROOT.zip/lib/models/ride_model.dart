import 'ride_status.dart';

/// Strict mapping for the public.rides table in the reference SQL V2 schema.
class RideModel {
  const RideModel({
    required this.id,
    required this.riderId,
    required this.driverId,
    required this.pickupAddress,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropoffAddress,
    required this.dropoffLat,
    required this.dropoffLng,
    required this.status,
    required this.driverLat,
    required this.driverLng,
    required this.rating,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String riderId;
  final String? driverId;
  final String pickupAddress;
  final double pickupLat;
  final double pickupLng;
  final String dropoffAddress;
  final double dropoffLat;
  final double dropoffLng;
  final RideStatus status;
  final double? driverLat;
  final double? driverLng;
  final int? rating;
  final DateTime createdAt;
  final DateTime updatedAt;

  factory RideModel.fromJson(Map<String, dynamic> json) {
    String requiredString(String key) {
      final value = json[key];
      if (value is! String || value.trim().isEmpty) {
        throw FormatException('Invalid or missing $key');
      }
      return value;
    }

    double requiredCoordinate(String key, double min, double max) {
      final value = json[key];
      if (value is! num) throw FormatException('Invalid or missing $key');
      final number = value.toDouble();
      if (!number.isFinite || number < min || number > max) {
        throw FormatException('Out-of-range $key');
      }
      return number;
    }

    double? optionalCoordinate(String key, double min, double max) {
      final value = json[key];
      if (value == null) return null;
      if (value is! num) throw FormatException('Invalid $key');
      final number = value.toDouble();
      if (!number.isFinite || number < min || number > max) {
        throw FormatException('Out-of-range $key');
      }
      return number;
    }

    DateTime requiredDate(String key) {
      final value = json[key];
      if (value is! String) throw FormatException('Invalid or missing $key');
      return DateTime.parse(value).toUtc();
    }

    final driverLat = optionalCoordinate('driver_lat', -90, 90);
    final driverLng = optionalCoordinate('driver_lng', -180, 180);
    if ((driverLat == null) != (driverLng == null)) {
      throw const FormatException('Driver coordinates must both be null or set');
    }

    final rawDriverId = json['driver_id'];
    if (rawDriverId != null && rawDriverId is! String) {
      throw const FormatException('Invalid driver_id');
    }
    final rawRating = json['rating'];
    if (rawRating != null && (rawRating is! num || rawRating % 1 != 0 || rawRating < 1 || rawRating > 5)) {
      throw const FormatException('Invalid rating');
    }

    return RideModel(
      id: requiredString('id'),
      riderId: requiredString('rider_id'),
      driverId: rawDriverId as String?,
      pickupAddress: requiredString('pickup_address'),
      pickupLat: requiredCoordinate('pickup_lat', -90, 90),
      pickupLng: requiredCoordinate('pickup_lng', -180, 180),
      dropoffAddress: requiredString('dropoff_address'),
      dropoffLat: requiredCoordinate('dropoff_lat', -90, 90),
      dropoffLng: requiredCoordinate('dropoff_lng', -180, 180),
      status: RideStatus.fromDatabase(requiredString('status')),
      driverLat: driverLat,
      driverLng: driverLng,
      rating: rawRating?.toInt(),
      createdAt: requiredDate('created_at'),
      updatedAt: requiredDate('updated_at'),
    );
  }

  /// Only columns granted to authenticated clients for a new rider request.
  Map<String, dynamic> toCreationMap({required String riderId}) => {
        'rider_id': riderId,
        'pickup_address': pickupAddress,
        'pickup_lat': pickupLat,
        'pickup_lng': pickupLng,
        'dropoff_address': dropoffAddress,
        'dropoff_lat': dropoffLat,
        'dropoff_lng': dropoffLng,
      };
}
