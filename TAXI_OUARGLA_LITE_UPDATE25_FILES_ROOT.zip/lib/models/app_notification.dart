class AppNotification {
  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.eventKey,
    required this.createdAt,
    this.rideId,
    this.readAt,
  });

  final String id;
  final String title;
  final String body;
  final String eventKey;
  final DateTime createdAt;
  final String? rideId;
  final DateTime? readAt;

  bool get isRead => readAt != null;

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'] as String,
      title: json['title'] as String,
      body: json['body'] as String,
      eventKey: json['event_key'] as String,
      createdAt: DateTime.parse(json['created_at'] as String).toLocal(),
      rideId: json['ride_id'] as String?,
      readAt: json['read_at'] == null
          ? null
          : DateTime.parse(json['read_at'] as String).toLocal(),
    );
  }
}
