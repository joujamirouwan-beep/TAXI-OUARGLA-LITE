/// The only ride states allowed by the V2 database contract.
enum RideStatus {
  searching,
  accepted,
  arrived,
  inProgress,
  completed,
  cancelled;

  String get databaseValue => switch (this) {
        RideStatus.searching => 'searching',
        RideStatus.accepted => 'accepted',
        RideStatus.arrived => 'arrived',
        RideStatus.inProgress => 'in_progress',
        RideStatus.completed => 'completed',
        RideStatus.cancelled => 'cancelled',
      };

  static RideStatus fromDatabase(String value) => switch (value) {
        'searching' => RideStatus.searching,
        'accepted' => RideStatus.accepted,
        'arrived' => RideStatus.arrived,
        'in_progress' => RideStatus.inProgress,
        'completed' => RideStatus.completed,
        'cancelled' => RideStatus.cancelled,
        _ => throw FormatException('Unknown ride status: $value'),
      };

  bool get isActiveForRider => switch (this) {
        searching || accepted || arrived || inProgress => true,
        completed || cancelled => false,
      };

  bool get isActiveForDriver => switch (this) {
        accepted || arrived || inProgress => true,
        searching || completed || cancelled => false,
      };

  bool get isFinal => this == completed || this == cancelled;
}
