class UserProfile {
  const UserProfile({required this.id, required this.role, required this.isVerified, required this.isOnline});

  final String id;
  final String role;
  final bool isVerified;
  final bool isOnline;

  factory UserProfile.fromJson(Map<String, dynamic> json, {required String expectedUserId}) {
    final id = json['id'];
    final role = json['role'];
    final verified = json['is_verified'];
    final online = json['is_online'];
    if (id is! String || id != expectedUserId) throw const FormatException('Profile user id mismatch');
    if (role is! String || !{'rider', 'driver', 'admin'}.contains(role)) {
      throw const FormatException('Unsupported profile role');
    }
    if (verified is! bool || online is! bool) throw const FormatException('Invalid profile flags');
    return UserProfile(id: id, role: role, isVerified: verified, isOnline: online);
  }
}
