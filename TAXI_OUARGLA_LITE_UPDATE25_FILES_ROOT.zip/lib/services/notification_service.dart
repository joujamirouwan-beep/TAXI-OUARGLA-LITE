import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/app_notification.dart';

class NotificationService {
  NotificationService(this._client);
  final SupabaseClient _client;

  String _requireUserId() {
    final id = _client.auth.currentUser?.id;
    if (id == null || id.isEmpty) throw StateError('يرجى تسجيل الدخول لعرض الإشعارات');
    return id;
  }

  Future<List<AppNotification>> fetchLatest({int limit = 50}) async {
    final userId = _requireUserId();
    final rows = await _client
        .from('user_notifications')
        .select('id,title,body,event_key,created_at,ride_id,read_at')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(limit.clamp(1, 100).toInt());
    if (_client.auth.currentUser?.id != userId) {
      throw StateError('تغيرت جلسة المستخدم أثناء تحميل الإشعارات');
    }
    return rows
        .map((row) => AppNotification.fromJson(Map<String, dynamic>.from(row)))
        .toList(growable: false);
  }

  Future<void> markRead(String notificationId) async {
    final userId = _requireUserId();
    final id = notificationId.trim();
    if (id.isEmpty) throw ArgumentError.value(notificationId, 'notificationId');
    await _client
        .from('user_notifications')
        .update({'read_at': DateTime.now().toUtc().toIso8601String()})
        .eq('id', id)
        .eq('user_id', userId)
        .isFilter('read_at', null);
    if (_client.auth.currentUser?.id != userId) {
      throw StateError('تغيرت جلسة المستخدم أثناء تحديث الإشعار');
    }
  }

  Future<void> markAllRead() async {
    final userId = _requireUserId();
    await _client
        .from('user_notifications')
        .update({'read_at': DateTime.now().toUtc().toIso8601String()})
        .eq('user_id', userId)
        .isFilter('read_at', null);
    if (_client.auth.currentUser?.id != userId) {
      throw StateError('تغيرت جلسة المستخدم أثناء تحديث الإشعارات');
    }
  }
}
