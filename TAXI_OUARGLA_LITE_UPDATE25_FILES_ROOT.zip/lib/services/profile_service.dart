import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_profile.dart';

class ProfileService {
  ProfileService(this._client);
  final SupabaseClient _client;

  Future<UserProfile?> fetchProfile(String userId) async {
    final row = await _client.from('profiles').select('id,role,is_verified,is_online').eq('id', userId).maybeSingle();
    if (row == null) return null;
    return UserProfile.fromJson(Map<String, dynamic>.from(row), expectedUserId: userId);
  }

  /// Polls only explicitly permitted columns. A table-wide Realtime `select *`
  /// would require SELECT on `phone`, which is intentionally never granted.
  Stream<UserProfile?> watchProfile(String userId) async* {
    yield await fetchProfile(userId);
    while (true) {
      await Future<void>.delayed(const Duration(seconds: 15));
      yield await fetchProfile(userId);
    }
  }
}
