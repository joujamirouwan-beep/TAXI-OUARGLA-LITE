import 'package:supabase_flutter/supabase_flutter.dart';

abstract interface class RideRpcClient {
  String? get currentUserId;
  Future<Object?> call(String function, {required Map<String, dynamic> params});
}

class SupabaseRideRpcClient implements RideRpcClient {
  SupabaseRideRpcClient(this._client);
  final SupabaseClient _client;

  @override
  String? get currentUserId => _client.auth.currentUser?.id;

  @override
  Future<Object?> call(String function, {required Map<String, dynamic> params}) async {
    return await _client.rpc(function, params: params);
  }
}
