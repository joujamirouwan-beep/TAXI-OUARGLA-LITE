import 'package:supabase_flutter/supabase_flutter.dart';

/// Supabase V2 service.
/// Trip requests contain locations and status only; payment is outside the app.
class TripService {
  TripService({SupabaseClient? client})
      : _supabase = client ?? Supabase.instance.client;

  final SupabaseClient _supabase;

  String get _userId {
    final id = _supabase.auth.currentUser?.id;
    if (id == null) throw Exception('يجب تسجيل الدخول أولاً');
    return id;
  }

  Future<Map<String, dynamic>> requestTaxi({
    required String pickupAddress,
    required double pickupLat,
    required double pickupLng,
    required String dropoffAddress,
    required double dropoffLat,
    required double dropoffLng,
  }) async {
    final userId = _userId;

    if (pickupAddress.trim().length < 2 ||
        dropoffAddress.trim().length < 2) {
      throw Exception('يرجى إدخال عنوان الانطلاق والوجهة');
    }
    _validateCoordinates(pickupLat, pickupLng);
    _validateCoordinates(dropoffLat, dropoffLng);

    final result = await _supabase.rpc(
      'create_ride_secure',
      params: {
        'p_pickup_address': pickupAddress.trim(),
        'p_pickup_lat': pickupLat,
        'p_pickup_lng': pickupLng,
        'p_dropoff_address': dropoffAddress.trim(),
        'p_dropoff_lat': dropoffLat,
        'p_dropoff_lng': dropoffLng,
      },
    );
    if (result is! Map) throw const FormatException('استجابة إنشاء الرحلة غير صحيحة');
    return Map<String, dynamic>.from(result);
  }

  Stream<List<Map<String, dynamic>>> streamPendingTrips() {
    _userId;
    return _pollRideRpc('list_available_rides_secure');
  }

  Stream<List<Map<String, dynamic>>> streamRide(String rideId) {
    _userId;
    return _pollRideRpc('list_my_rides_secure').map((rows) =>
        rows.where((row) => row['id'] == rideId).toList(growable: false));
  }

  /// Returns the rider's latest unfinished trip so the app can resume tracking
  /// after it is closed or restarted.
  Future<Map<String, dynamic>?> getActiveRiderRide() async {
    final userId = _userId;
    final rows = await _loadRideRpc('list_my_rides_secure');
    final matches = rows.where((row) => row['rider_id'] == userId &&
        ['searching', 'accepted', 'arrived', 'in_progress'].contains(row['status']));
    return matches.isEmpty ? null : matches.first;
  }

  Future<Map<String, dynamic>?> getActiveDriverRide() async {
    final userId = _userId;
    final rows = await _loadRideRpc('list_my_rides_secure');
    final matches = rows.where((row) => row['driver_id'] == userId &&
        ['accepted', 'arrived', 'in_progress'].contains(row['status']));
    return matches.isEmpty ? null : matches.first;
  }

  Future<bool> getDriverOnlineStatus() async {
    final userId = _userId;
    final row = await _supabase
        .from('profiles')
        .select('is_online')
        .eq('id', userId)
        .single();
    return row['is_online'] == true;
  }

  /// Returns the other participant's phone only during an active assigned ride.
  /// The database RPC enforces participant identity and ride state.
  Future<String> getRideContactPhone(String rideId) async {
    _userId;
    final id = rideId.trim();
    if (id.isEmpty) throw ArgumentError.value(rideId, 'rideId');
    final result = await _supabase.rpc(
      'get_ride_contact_phone_secure',
      params: {'p_ride_id': id},
    );
    if (result is! String || result.trim().isEmpty) {
      throw StateError('رقم هاتف الطرف الآخر غير متاح حالياً');
    }
    return result.trim();
  }

  Future<bool> acceptTrip(String rideId) async {
    _userId;
    final result = await _supabase.rpc(
      'accept_ride_secure',
      params: {'p_ride_id': rideId},
    );
    return result == true;
  }

  Future<bool> setDriverOnline(bool isOnline) async {
    _userId;
    final result = await _supabase.rpc(
      'set_driver_online_secure',
      params: {'p_is_online': isOnline},
    );
    return result == true;
  }

  Future<bool> setRideStatus({
    required String rideId,
    required String nextStatus,
  }) async {
    _userId;
    const allowed = {'arrived', 'in_progress', 'completed'};
    if (!allowed.contains(nextStatus)) {
      throw ArgumentError.value(nextStatus, 'nextStatus');
    }

    final result = await _supabase.rpc(
      'set_ride_status_secure',
      params: {
        'p_ride_id': rideId,
        'p_next_status': nextStatus,
      },
    );
    return result == true;
  }

  Future<bool> cancelSearchingTrip(String rideId) async {
    _userId;
    final result = await _supabase.rpc(
      'cancel_searching_ride_secure',
      params: {'p_ride_id': rideId},
    );
    return result == true;
  }

  Future<bool> updateDriverLocation({
    required String rideId,
    required double latitude,
    required double longitude,
  }) async {
    _userId;
    _validateCoordinates(latitude, longitude);
    final result = await _supabase.rpc(
      'update_driver_location_secure',
      params: {
        'p_ride_id': rideId,
        'p_lat': latitude,
        'p_lng': longitude,
      },
    );
    return result == true;
  }

  Future<bool> rateCompletedTrip({
    required String rideId,
    required int rating,
  }) async {
    _userId;
    if (rating < 1 || rating > 5) {
      throw ArgumentError.value(rating, 'rating');
    }
    final result = await _supabase.rpc(
      'rate_completed_ride_secure',
      params: {
        'p_ride_id': rideId,
        'p_rating': rating,
      },
    );
    return result == true;
  }

  Future<List<Map<String, dynamic>>> _loadRideRpc(String name) async {
    final result = await _supabase.rpc(name);
    if (result is! List) throw StateError('استجابة غير صحيحة من الخادم');
    return result.map((row) => Map<String, dynamic>.from(row as Map)).toList(growable: false);
  }

  Stream<List<Map<String, dynamic>>> _pollRideRpc(String name) async* {
    while (true) {
      yield await _loadRideRpc(name);
      await Future<void>.delayed(const Duration(seconds: 5));
    }
  }

  void _validateCoordinates(double lat, double lng) {
    if (!lat.isFinite ||
        !lng.isFinite ||
        lat < -90 ||
        lat > 90 ||
        lng < -180 ||
        lng > 180) {
      throw ArgumentError('إحداثيات الموقع غير صحيحة');
    }
  }
}
