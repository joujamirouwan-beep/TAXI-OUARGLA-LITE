import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/ride_status.dart';
import 'ride_rpc_client.dart';

/// Implements the existing reference SQL V2 contract, not the incompatible
/// experimental JSON-returning RPC contract from the earlier overlay.
class RideService {
  RideService({required SupabaseClient client, RideRpcClient? rpc})
      : _rpc = rpc ?? SupabaseRideRpcClient(client);

  final RideRpcClient _rpc;

  String _requireUser() {
    final id = _rpc.currentUserId;
    if (id == null || id.trim().isEmpty) {
      throw StateError('يجب تسجيل الدخول أولاً');
    }
    return id;
  }

  void _ensureSameSession(String expectedUserId) {
    if (_rpc.currentUserId != expectedUserId) {
      throw StateError('تغيرت جلسة المستخدم أثناء تنفيذ الطلب. تحقق من حالة الرحلة قبل إعادة المحاولة.');
    }
  }

  String _rideId(String value) {
    final id = value.trim();
    if (id.isEmpty) throw ArgumentError.value(value, 'rideId');
    return id;
  }

  String _address(String value, String field) {
    final normalized = value.trim();
    if (normalized.length < 2 || normalized.length > 300) {
      throw ArgumentError.value(value, field, 'يجب أن يكون العنوان بين 2 و300 حرف');
    }
    return normalized;
  }

  void _coordinates(double lat, double lng) {
    if (!lat.isFinite || !lng.isFinite || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      throw ArgumentError('إحداثيات الموقع غير صحيحة');
    }
  }

  /// Secure RPC derives the rider from auth.uid and owns all protected fields.
  Future<Map<String, dynamic>> createRide({
    required String pickupAddress,
    required double pickupLat,
    required double pickupLng,
    required String dropoffAddress,
    required double dropoffLat,
    required double dropoffLng,
  }) async {
    final userId = _requireUser();
    final pickup = _address(pickupAddress, 'pickupAddress');
    final dropoff = _address(dropoffAddress, 'dropoffAddress');
    _coordinates(pickupLat, pickupLng);
    _coordinates(dropoffLat, dropoffLng);

    try {
      final result = await _rpc.call('create_ride_secure', params: {
        'p_pickup_address': pickup,
        'p_pickup_lat': pickupLat,
        'p_pickup_lng': pickupLng,
        'p_dropoff_address': dropoff,
        'p_dropoff_lat': dropoffLat,
        'p_dropoff_lng': dropoffLng,
      });
      _ensureSameSession(userId);
      if (result is! Map) {
        throw const FormatException('استجابة إنشاء الرحلة غير صحيحة');
      }
      return Map<String, dynamic>.from(result);
    } on PostgrestException catch (error) {
      if (error.code == '23505') {
        throw StateError('لديك طلب رحلة نشط بالفعل. تحقق من رحلتك الحالية.');
      }
      rethrow;
    }
  }

  Future<String> getRideContactPhone(String rideId) async {
    final userId = _requireUser();
    final result = await _rpc.call('get_ride_contact_phone_secure', params: {
      'p_ride_id': _rideId(rideId),
    });
    _ensureSameSession(userId);
    if (result is! String || result.trim().isEmpty) {
      throw StateError('رقم هاتف الطرف الآخر غير متاح حالياً');
    }
    return result.trim();
  }

  Future<bool> acceptRide(String rideId) => _boolRpc(
        'accept_ride_secure',
        {'p_ride_id': _rideId(rideId)},
      );

  Future<bool> setRideStatus(String rideId, RideStatus next) {
    const allowed = {RideStatus.arrived, RideStatus.inProgress, RideStatus.completed};
    if (!allowed.contains(next)) throw ArgumentError.value(next, 'next');
    return _boolRpc('set_ride_status_secure', {
      'p_ride_id': _rideId(rideId),
      'p_next_status': next.databaseValue,
    });
  }

  Future<bool> cancelSearchingRide(String rideId) => _boolRpc(
        'cancel_searching_ride_secure',
        {'p_ride_id': _rideId(rideId)},
      );

  Future<bool> updateDriverLocation({required String rideId, required double lat, required double lng}) {
    _coordinates(lat, lng);
    return _boolRpc('update_driver_location_secure', {
      'p_ride_id': _rideId(rideId),
      'p_lat': lat,
      'p_lng': lng,
    });
  }

  Future<bool> setDriverOnline(bool online) =>
      _boolRpc('set_driver_online_secure', {'p_is_online': online});

  Future<bool> rateCompletedRide({required String rideId, required int rating}) {
    if (rating < 1 || rating > 5) throw ArgumentError.value(rating, 'rating');
    return _boolRpc('rate_completed_ride_secure', {
      'p_ride_id': _rideId(rideId),
      'p_rating': rating,
    });
  }

  Future<bool> _boolRpc(String function, Map<String, dynamic> params) async {
    final userId = _requireUser();
    final result = await _rpc.call(function, params: params);
    _ensureSameSession(userId);
    if (result is! bool) {
      throw FormatException('استجابة غير متوقعة من خدمة الرحلات: $function');
    }
    return result;
  }
}
