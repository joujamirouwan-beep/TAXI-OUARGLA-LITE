import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'profile_router.dart';

/// Resolves the current Supabase session and reacts to sign-in/sign-out changes.
class AuthWrapper extends StatefulWidget {
  const AuthWrapper({
    super.key,
    required this.client,
    required this.signedOutBuilder,
    required this.authenticatedBuilder,
    required this.loadingBuilder,
    required this.errorBuilder,
  });

  final SupabaseClient client;
  final WidgetBuilder signedOutBuilder;
  final Widget Function(BuildContext context, User user) authenticatedBuilder;
  final WidgetBuilder loadingBuilder;
  final Widget Function(BuildContext context, Object error) errorBuilder;

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  StreamSubscription<AuthState>? _subscription;
  User? _user;
  Object? _error;
  bool _initialized = false;
  int _subscriptionGeneration = 0;

  @override
  void initState() {
    super.initState();
    _user = widget.client.auth.currentUser;
    _initialized = true;
    _listen();
  }

  void _listen() {
    final generation = ++_subscriptionGeneration;
    _subscription?.cancel();
    _subscription = widget.client.auth.onAuthStateChange.listen(
      (event) {
        if (!mounted || generation != _subscriptionGeneration) return;
        setState(() {
          _user = event.session?.user;
          _error = null;
          _initialized = true;
        });
      },
      onError: (Object error, StackTrace stackTrace) {
        if (!mounted || generation != _subscriptionGeneration) return;
        setState(() => _error = error);
      },
    );
  }

  @override
  void didUpdateWidget(covariant AuthWrapper oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.client, widget.client)) {
      _user = widget.client.auth.currentUser;
      _error = null;
      _listen();
    }
  }

  @override
  void dispose() {
    _subscriptionGeneration++;
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final error = _error;
    if (error != null) return widget.errorBuilder(context, error);
    if (!_initialized) return widget.loadingBuilder(context);
    final user = _user;
    if (user == null) return widget.signedOutBuilder(context);
    return widget.authenticatedBuilder(context, user);
  }
}

/// Convenience builder for apps that want the standard profile-based routing.
Widget buildProfileRouter({
  required BuildContext context,
  required SupabaseClient client,
  required User user,
  required ProfileRouterBuilder pages,
}) {
  return ProfileRouter(
    key: ValueKey(user.id),
    userId: user.id,
    client: client,
    pages: pages,
  );
}
