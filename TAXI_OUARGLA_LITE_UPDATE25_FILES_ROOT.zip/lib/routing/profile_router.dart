import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/user_profile.dart';
import '../services/profile_service.dart';
import 'profile_destination.dart';

class ProfileRouterBuilder {
  const ProfileRouterBuilder({
    required this.riderHome,
    required this.driverHome,
    required this.driverPending,
    required this.adminHome,
    required this.loading,
    required this.missingProfile,
    required this.error,
  });

  final WidgetBuilder riderHome;
  final WidgetBuilder driverHome;
  final WidgetBuilder driverPending;
  final WidgetBuilder adminHome;
  final WidgetBuilder loading;
  final WidgetBuilder missingProfile;
  final Widget Function(BuildContext context, Object error) error;
}

/// Routes only after loading the authenticated user's own profile row.
/// Widget routing is not an authorization boundary; enforce access in RLS/RPC.
class ProfileRouter extends StatefulWidget {
  const ProfileRouter({
    super.key,
    required this.userId,
    required this.client,
    required this.pages,
  });

  final String userId;
  final SupabaseClient client;
  final ProfileRouterBuilder pages;

  @override
  State<ProfileRouter> createState() => _ProfileRouterState();
}

class _ProfileRouterState extends State<ProfileRouter> {
  late Stream<UserProfile?> _profileStream;

  @override
  void initState() {
    super.initState();
    _bindStream();
  }

  void _bindStream() {
    _profileStream = ProfileService(widget.client).watchProfile(widget.userId);
  }

  @override
  void didUpdateWidget(covariant ProfileRouter oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.userId != widget.userId ||
        !identical(oldWidget.client, widget.client)) {
      _bindStream();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<UserProfile?>(
      stream: _profileStream,
      builder: (context, snapshot) {
        if (snapshot.hasError) return widget.pages.error(context, snapshot.error!);
        if (snapshot.connectionState == ConnectionState.waiting &&
            !snapshot.hasData) {
          return widget.pages.loading(context);
        }
        final profile = snapshot.data;
        if (profile == null) return widget.pages.missingProfile(context);
        if (profile.id != widget.userId) {
          return widget.pages.error(
            context,
            const FormatException('Profile does not match authenticated user'),
          );
        }
        switch (destinationForProfile(profile)) {
          case ProfileDestination.riderHome:
            return widget.pages.riderHome(context);
          case ProfileDestination.driverHome:
            return widget.pages.driverHome(context);
          case ProfileDestination.driverPending:
            return widget.pages.driverPending(context);
          case ProfileDestination.adminHome:
            return widget.pages.adminHome(context);
          case ProfileDestination.invalid:
            return widget.pages.error(
              context,
              const FormatException('Unsupported profile role'),
            );
        }
      },
    );
  }
}
