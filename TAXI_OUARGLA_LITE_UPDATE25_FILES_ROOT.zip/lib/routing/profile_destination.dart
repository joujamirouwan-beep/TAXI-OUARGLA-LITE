import '../models/user_profile.dart';

enum ProfileDestination {
  riderHome,
  driverHome,
  driverPending,
  adminHome,
  invalid,
}

ProfileDestination destinationForProfile(UserProfile profile) {
  switch (profile.role) {
    case 'rider':
      return ProfileDestination.riderHome;
    case 'driver':
      return profile.isVerified
          ? ProfileDestination.driverHome
          : ProfileDestination.driverPending;
    case 'admin':
      return ProfileDestination.adminHome;
    default:
      return ProfileDestination.invalid;
  }
}
