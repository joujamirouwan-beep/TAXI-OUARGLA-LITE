import '../models/ride_model.dart';
import '../models/ride_status.dart';

/// Pure presentation policy. Database RPC/RLS remains the security boundary.
class RideFlowPolicy {
  const RideFlowPolicy._();

  static bool riderCanCancel(RideModel ride, String userId) =>
      ride.riderId == userId &&
      ride.status == RideStatus.searching &&
      ride.driverId == null;

  static bool driverCanAccept(RideModel ride, String userId) =>
      ride.status == RideStatus.searching &&
      ride.driverId == null &&
      ride.riderId != userId;

  static RideStatus? nextDriverStatus(RideStatus current) => switch (current) {
        RideStatus.accepted => RideStatus.arrived,
        RideStatus.arrived => RideStatus.inProgress,
        RideStatus.inProgress => RideStatus.completed,
        RideStatus.searching || RideStatus.completed || RideStatus.cancelled => null,
      };

  static bool riderCanRate(RideModel ride, String userId) =>
      ride.riderId == userId &&
      ride.status == RideStatus.completed &&
      ride.rating == null;

  static bool driverCanShareLocation(RideModel ride, String userId) =>
      ride.driverId == userId && ride.status.isActiveForDriver;

  static bool isActiveForUser(RideModel ride, String userId) {
    if (ride.riderId == userId) return ride.status.isActiveForRider;
    if (ride.driverId == userId) return ride.status.isActiveForDriver;
    return false;
  }
}
