import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

/// Presentation-only OpenStreetMap layer.
///
/// Coordinates must come from a real user selection, a validated ride row,
/// or a location service. This widget intentionally invents no coordinates
/// and does not request device-location permission.
class OsmRideMap extends StatelessWidget {
  const OsmRideMap({
    super.key,
    required this.initialCenter,
    this.initialZoom = 13,
    this.pickup,
    this.dropoff,
    this.driver,
    this.onMapTap,
  });

  final LatLng initialCenter;
  final double initialZoom;
  final LatLng? pickup;
  final LatLng? dropoff;
  final LatLng? driver;
  final ValueChanged<LatLng>? onMapTap;

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      if (pickup != null)
        Marker(
          point: pickup!,
          width: 42,
          height: 42,
          child: const Icon(Icons.trip_origin, color: Colors.green, size: 34),
        ),
      if (dropoff != null)
        Marker(
          point: dropoff!,
          width: 42,
          height: 42,
          child: const Icon(Icons.location_on, color: Colors.red, size: 38),
        ),
      if (driver != null)
        Marker(
          point: driver!,
          width: 42,
          height: 42,
          child: const Icon(Icons.local_taxi, color: Colors.blue, size: 34),
        ),
    ];

    return FlutterMap(
      options: MapOptions(
        initialCenter: initialCenter,
        initialZoom: initialZoom,
        onTap: onMapTap == null ? null : (tapPosition, point) => onMapTap!(point),
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.taxiouargla.lite',
        ),
        if (markers.isNotEmpty) MarkerLayer(markers: markers),
        const RichAttributionWidget(
          attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
        ),
      ],
    );
  }
}
