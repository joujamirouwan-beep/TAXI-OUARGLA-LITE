import '../models/ride_model.dart';
import '../models/ride_status.dart';
import '../services/ride_service.dart';
import 'ride_data_source.dart';

class RideRepository {
  RideRepository({required RideService service, required RideDataSource dataSource})
      : _service = service, _dataSource = dataSource;

  final RideService _service;
  final RideDataSource _dataSource;

  Stream<List<RideModel>> watchAvailableRides() => _parse(_dataSource.watchAvailableRideRows());

  Stream<List<RideModel>> watchRiderRides(String riderId) => _parse(_dataSource.watchRiderRideRows(_id(riderId)));

  Stream<List<RideModel>> watchDriverRides(String driverId) => _parse(_dataSource.watchDriverRideRows(_id(driverId)));

  Future<Map<String, dynamic>> createRide({
    required String pickupAddress, required double pickupLat, required double pickupLng,
    required String dropoffAddress, required double dropoffLat, required double dropoffLng,
  }) => _service.createRide(
    pickupAddress: pickupAddress, pickupLat: pickupLat, pickupLng: pickupLng,
    dropoffAddress: dropoffAddress, dropoffLat: dropoffLat, dropoffLng: dropoffLng,
  );

  Future<bool> acceptRide(String rideId) => _service.acceptRide(rideId);
  Future<String> getRideContactPhone(String rideId) => _service.getRideContactPhone(rideId);
  Future<bool> setRideStatus(String rideId, RideStatus status) => _service.setRideStatus(rideId, status);
  Future<bool> cancelSearchingRide(String rideId) => _service.cancelSearchingRide(rideId);
  Future<bool> updateDriverLocation({required String rideId, required double lat, required double lng}) =>
      _service.updateDriverLocation(rideId: rideId, lat: lat, lng: lng);
  Future<bool> setDriverOnline(bool online) => _service.setDriverOnline(online);
  Future<bool> rateCompletedRide({required String rideId, required int rating}) =>
      _service.rateCompletedRide(rideId: rideId, rating: rating);

  Stream<List<RideModel>> _parse(Stream<List<Map<String, dynamic>>> source) =>
      source.map((rows) => rows.map(RideModel.fromJson).toList(growable: false));

  String _id(String value) {
    final id = value.trim();
    if (id.isEmpty) throw ArgumentError.value(value, 'userId');
    return id;
  }
}
