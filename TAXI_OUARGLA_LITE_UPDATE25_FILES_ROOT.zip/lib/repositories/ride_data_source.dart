import 'package:supabase_flutter/supabase_flutter.dart';

abstract interface class RideDataSource {
  Stream<List<Map<String, dynamic>>> watchAvailableRideRows();
  Stream<List<Map<String, dynamic>>> watchRiderRideRows(String riderId);
  Stream<List<Map<String, dynamic>>> watchDriverRideRows(String driverId);
}

/// Uses bounded RPC result sets instead of broad table SELECT/Realtime streams.
/// Polling avoids exposing unassigned searching rides through RLS.
class SupabaseRideDataSource implements RideDataSource {
  SupabaseRideDataSource(this._client);
  final SupabaseClient _client;

  Stream<List<Map<String, dynamic>>> _poll(String rpcName) async* {
    while (true) {
      final result = await _client.rpc(rpcName);
      if (result is! List) {
        throw StateError('Invalid response from $rpcName');
      }
      yield result
          .map((row) => Map<String, dynamic>.from(row as Map))
          .toList(growable: false);
      await Future<void>.delayed(const Duration(seconds: 5));
    }
  }

  @override
  Stream<List<Map<String, dynamic>>> watchAvailableRideRows() =>
      _poll('list_available_rides_secure');

  @override
  Stream<List<Map<String, dynamic>>> watchRiderRideRows(String riderId) =>
      _poll('list_my_rides_secure').map((rows) => rows
          .where((row) => row['rider_id'] == riderId)
          .toList(growable: false));

  @override
  Stream<List<Map<String, dynamic>>> watchDriverRideRows(String driverId) =>
      _poll('list_my_rides_secure').map((rows) => rows
          .where((row) => row['driver_id'] == driverId)
          .toList(growable: false));
}
