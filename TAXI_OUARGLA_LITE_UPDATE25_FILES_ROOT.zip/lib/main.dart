import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app/app_dependencies.dart';
import 'screens/auth/auth_gate_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
    runApp(const ConfigurationApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  AppDependencies.initialize(Supabase.instance.client);
  runApp(const TaxiOuarglaApp());
}

class TaxiOuarglaApp extends StatelessWidget {
  const TaxiOuarglaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'طاكسي ورڨلة لايت',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFFC107), brightness: Brightness.dark),
      useMaterial3: true,
    ),
    home: const AuthGateScreen(),
  );
}

class ConfigurationApp extends StatelessWidget {
  const ConfigurationApp({super.key});
  @override
  Widget build(BuildContext context) => const MaterialApp(
    home: Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('يلزم إعداد SUPABASE_URL و SUPABASE_ANON_KEY قبل تشغيل التطبيق.', textAlign: TextAlign.center),
        ),
      ),
    ),
  );
}
