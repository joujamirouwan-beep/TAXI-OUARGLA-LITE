import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../app/app_dependencies.dart';
import '../errors/app_error_message.dart';
import '../flows/ride_flow_policy.dart';
import '../models/ride_model.dart';
import '../models/ride_status.dart';
import '../widgets/osm_ride_map.dart';
import 'ride_tracking_screen.dart';
import 'notifications_screen.dart';

const LatLng _ouarglaCenter = LatLng(31.9522, 5.3242);

class RiderHomeScreen extends StatefulWidget {
  const RiderHomeScreen({super.key});

  @override
  State<RiderHomeScreen> createState() => _RiderHomeScreenState();
}

class _RiderHomeScreenState extends State<RiderHomeScreen> {
  final _pickupAddress = TextEditingController(text: 'موقعي الحالي');
  final _dropoffAddress = TextEditingController();
  LatLng? _pickup;
  LatLng? _dropoff;
  bool _locating = false;
  bool _creating = false;

  @override
  void dispose() {
    _pickupAddress.dispose();
    _dropoffAddress.dispose();
    super.dispose();
  }

  Future<void> _locatePickup() async {
    setState(() => _locating = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('فعّل خدمة الموقع GPS في الهاتف.');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('إذن الموقع غير متاح. يمكنك اختيار نقطة الانطلاق من الخريطة.');
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      if (!mounted) return;
      setState(() {
        _pickup = LatLng(position.latitude, position.longitude);
        _pickupAddress.text = 'موقعي الحالي';
      });
    } catch (error) {
      _message('تعذر تحديد الموقع: ${AppErrorMessage.from(error)}');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _choosePoint({required bool pickup}) async {
    final initial = pickup ? (_pickup ?? _ouarglaCenter) : (_dropoff ?? _ouarglaCenter);
    final selected = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(builder: (_) => _MapPointPicker(initial: initial)),
    );
    if (!mounted || selected == null) return;
    setState(() {
      if (pickup) {
        _pickup = selected;
        if (_pickupAddress.text.trim().isEmpty || _pickupAddress.text == 'موقعي الحالي') {
          _pickupAddress.text = 'نقطة انطلاق على الخريطة';
        }
      } else {
        _dropoff = selected;
        if (_dropoffAddress.text.trim().isEmpty) {
          _dropoffAddress.text = 'وجهة محددة على الخريطة';
        }
      }
    });
  }

  Future<void> _createRide() async {
    final pickup = _pickup;
    final dropoff = _dropoff;
    if (pickup == null || dropoff == null) {
      _message('حدد مكان الانطلاق والوجهة على الخريطة أولاً.');
      return;
    }
    if (_pickupAddress.text.trim().length < 2 || _dropoffAddress.text.trim().length < 2) {
      _message('أدخل وصفاً واضحاً لمكان الانطلاق والوجهة.');
      return;
    }
    setState(() => _creating = true);
    try {
      await AppDependencies.instance.rideRepository.createRide(
        pickupAddress: _pickupAddress.text.trim(),
        pickupLat: pickup.latitude,
        pickupLng: pickup.longitude,
        dropoffAddress: _dropoffAddress.text.trim(),
        dropoffLat: dropoff.latitude,
        dropoffLng: dropoff.longitude,
      );
      if (!mounted) return;
      _message('تم إرسال طلب الرحلة. انتظر قبول أحد السائقين.');
      setState(() {
        _dropoff = null;
        _dropoffAddress.clear();
      });
    } catch (error) {
      _message('تعذر إرسال الطلب: ${AppErrorMessage.from(error)}');
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  void _message(String text) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final deps = AppDependencies.instance;
    final userId = deps.client.auth.currentUser?.id;
    if (userId == null) return const Scaffold(body: Center(child: Text('يرجى تسجيل الدخول')));
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('طاكسي ورڨلة لايت'),
          actions: [
            IconButton(
              tooltip: 'الإشعارات',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
              icon: const Icon(Icons.notifications_none),
            ),
            IconButton(tooltip: 'تسجيل الخروج', onPressed: () => deps.client.auth.signOut(), icon: const Icon(Icons.logout)),
          ],
        ),
        body: Column(children: [
          Expanded(
            flex: 5,
            child: StreamBuilder<List<RideModel>>(
              stream: deps.rideRepository.watchRiderRides(userId),
              builder: (context, snapshot) {
                if (snapshot.hasError) return const Center(child: Text('تعذر تحميل الرحلات. تحقق من اتصالك.'));
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final rides = [...snapshot.data!]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
                final active = rides.where((ride) => ride.status.isActiveForRider).toList();
                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    _requestPanel(canRequest: active.isEmpty),
                    const SizedBox(height: 14),
                    Text('رحلاتي', style: Theme.of(context).textTheme.titleLarge),
                    if (rides.isEmpty) const Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('لا توجد رحلات مسجلة بعد.', textAlign: TextAlign.center),
                    ),
                    if (active.isNotEmpty) const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('لديك طلب نشط. لا يمكنك إنشاء طلب آخر حتى تنتهي الرحلة أو تُلغى.', style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                    ...rides.map((ride) => _RiderRideCard(ride: ride, userId: userId)),
                  ],
                );
              },
            ),
          ),
        ]),
      ),
    );
  }

  Widget _requestPanel({required bool canRequest}) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('اطلب رحلة داخل ورقلة', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        const Text('الاتفاق على الأجرة يتم مباشرة بين الراكب والسائق خارج التطبيق.'),
        if (!canRequest) const Padding(padding: EdgeInsets.only(top: 8), child: Text('لديك رحلة نشطة حالياً؛ لا يمكن إرسال طلب جديد قبل انتهائها.', style: TextStyle(fontWeight: FontWeight.w600))),
        const SizedBox(height: 12),
        TextField(controller: _pickupAddress, decoration: const InputDecoration(labelText: 'وصف مكان الانطلاق')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: !canRequest || _locating || _creating ? null : _locatePickup,
          icon: _locating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location),
          label: const Text('تحديد موقعي الحالي'),
        ),
        OutlinedButton.icon(
          onPressed: !canRequest || _creating ? null : () => _choosePoint(pickup: true),
          icon: const Icon(Icons.map_outlined), label: const Text('اختيار الانطلاق من الخريطة'),
        ),
        const SizedBox(height: 8),
        TextField(controller: _dropoffAddress, decoration: const InputDecoration(labelText: 'وصف الوجهة')),
        OutlinedButton.icon(
          onPressed: !canRequest || _creating ? null : () => _choosePoint(pickup: false),
          icon: const Icon(Icons.location_on_outlined), label: const Text('اختيار الوجهة من الخريطة'),
        ),
        if (_pickup != null || _dropoff != null) ...[
          const SizedBox(height: 8),
          SizedBox(height: 150, child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: OsmRideMap(initialCenter: _pickup ?? _dropoff ?? _ouarglaCenter, pickup: _pickup, dropoff: _dropoff),
          )),
        ],
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: !canRequest || _creating ? null : _createRide,
          icon: _creating ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.local_taxi),
          label: Text(_creating ? 'جارٍ إرسال الطلب…' : 'إرسال طلب الرحلة'),
        ),
      ]),
    ),
  );
}

class _MapPointPicker extends StatefulWidget {
  const _MapPointPicker({required this.initial});
  final LatLng initial;
  @override
  State<_MapPointPicker> createState() => _MapPointPickerState();
}

class _MapPointPickerState extends State<_MapPointPicker> {
  late LatLng _selected = widget.initial;
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('حدد النقطة على الخريطة')),
      body: Column(children: [
        const Padding(padding: EdgeInsets.all(10), child: Text('اضغط على الخريطة لتحديد الموقع بدقة.')),
        Expanded(child: OsmRideMap(
          initialCenter: widget.initial,
          initialZoom: 14,
          dropoff: _selected,
          onMapTap: (point) => setState(() => _selected = point),
        )),
        Padding(padding: const EdgeInsets.all(12), child: SizedBox(
          width: double.infinity,
          child: FilledButton(onPressed: () => Navigator.pop(context, _selected), child: const Text('تأكيد الموقع')),
        )),
      ]),
    ),
  );
}

class _RiderRideCard extends StatelessWidget {
  const _RiderRideCard({required this.ride, required this.userId});
  final RideModel ride;
  final String userId;
  @override
  Widget build(BuildContext context) {
    final repo = AppDependencies.instance.rideRepository;
    final canCancel = RideFlowPolicy.riderCanCancel(ride, userId);
    final canRate = RideFlowPolicy.riderCanRate(ride, userId);
    return Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_status(ride.status), style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Text('من: ${ride.pickupAddress}'), Text('إلى: ${ride.dropoffAddress}'),
        if (ride.status.isActiveForRider)
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => RideTrackingScreen(rideId: ride.id)),
              ),
              icon: const Icon(Icons.map_outlined),
              label: const Text('متابعة الرحلة والاتصال'),
            ),
          ),
        if (ride.driverLat != null && ride.driverLng != null && ride.status.isActiveForRider) ...[
          const SizedBox(height: 10),
          const Text('موقع السائق المباشر', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          SizedBox(
            height: 190,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: OsmRideMap(
                initialCenter: LatLng(ride.driverLat!, ride.driverLng!),
                initialZoom: 15,
                pickup: LatLng(ride.pickupLat, ride.pickupLng),
                dropoff: LatLng(ride.dropoffLat, ride.dropoffLng),
                driver: LatLng(ride.driverLat!, ride.driverLng!),
              ),
            ),
          ),
        ],
        if (canCancel) Align(alignment: Alignment.centerLeft, child: TextButton.icon(
          onPressed: () => _run(context, () => repo.cancelSearchingRide(ride.id)),
          icon: const Icon(Icons.cancel_outlined), label: const Text('إلغاء الطلب'),
        )),
        if (canRate) Wrap(spacing: 4, children: List.generate(5, (i) => IconButton(
          tooltip: 'تقييم ${i + 1} من 5', icon: const Icon(Icons.star_border),
          onPressed: () => _run(context, () => repo.rateCompletedRide(rideId: ride.id, rating: i + 1)),
        ))),
      ]),
    ));
  }
}

String _status(RideStatus status) => switch (status) {
  RideStatus.searching => 'جارٍ البحث عن سائق',
  RideStatus.accepted => 'تم قبول الرحلة',
  RideStatus.arrived => 'وصل السائق',
  RideStatus.inProgress => 'الرحلة جارية',
  RideStatus.completed => 'اكتملت الرحلة',
  RideStatus.cancelled => 'أُلغيت الرحلة',
};

Future<void> _run(BuildContext context, Future<bool> Function() action) async {
  try {
    final ok = await action();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم تنفيذ العملية' : 'لم يتم تنفيذ العملية')));
  } catch (_) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تنفيذ العملية. تحقق من الاتصال وحالة الرحلة.')));
  }
}
