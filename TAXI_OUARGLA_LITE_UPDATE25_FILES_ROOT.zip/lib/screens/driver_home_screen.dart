import 'dart:async';

import 'package:flutter/material.dart';

import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../app/app_dependencies.dart';
import '../errors/app_error_message.dart';
import '../flows/ride_flow_policy.dart';
import '../models/ride_model.dart';
import '../models/ride_status.dart';
import 'notifications_screen.dart';

/// Driver screen: available requests and the driver's assigned rides.
class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});
  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  bool _online = false;
  bool _onlineLoaded = false;
  bool _onlineBusy = false;
  StreamSubscription<Position>? _locationSubscription;
  String? _trackingRideId;
  bool _trackingStartInFlight = false;
  bool _locationUpdateBusy = false;

  @override
  void initState() {
    super.initState();
    _loadOnlineState();
  }

  Future<void> _loadOnlineState() async {
    try {
      final id = Supabase.instance.client.auth.currentUser?.id;
      if (id == null) return;
      final row = await Supabase.instance.client.from('profiles').select('is_online').eq('id', id).single();
      if (!mounted) return;
      setState(() { _online = row['is_online'] == true; _onlineLoaded = true; });
    } catch (_) {
      if (mounted) setState(() => _onlineLoaded = true);
    }
  }

  @override
  void dispose() {
    _locationSubscription?.cancel();
    super.dispose();
  }

  void _syncLiveLocation(List<RideModel> rides) {
    RideModel? current;
    for (final ride in rides) {
      if (ride.status.isActiveForDriver) {
        current = ride;
        break;
      }
    }
    if (current == null) {
      _locationSubscription?.cancel();
      _locationSubscription = null;
      _trackingRideId = null;
      return;
    }
    if (_trackingRideId == current.id || _trackingStartInFlight) return;
    _trackingRideId = current.id;
    _trackingStartInFlight = true;
    _startLiveLocation(current.id);
  }

  Future<void> _startLiveLocation(String rideId) async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw StateError('فعّل GPS لمشاركة موقعك أثناء الرحلة.');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        throw StateError('إذن الموقع غير متاح؛ لن يتم تحديث موقعك أثناء الرحلة.');
      }
      if (!mounted || _trackingRideId != rideId) return;
      _locationSubscription?.cancel();
      _locationSubscription = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 25,
        ),
      ).listen((position) async {
        if (_locationUpdateBusy || !mounted || _trackingRideId != rideId) return;
        _locationUpdateBusy = true;
        try {
          await AppDependencies.instance.rideRepository.updateDriverLocation(
            rideId: rideId,
            lat: position.latitude,
            lng: position.longitude,
          );
        } catch (_) {
          // A later GPS update can recover from temporary network failures.
        } finally {
          _locationUpdateBusy = false;
        }
      });
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر تشغيل مشاركة الموقع: ${AppErrorMessage.from(error)}')),
        );
      }
      _trackingRideId = null;
    } finally {
      _trackingStartInFlight = false;
    }
  }

  Future<void> _signOut() async {
    try {
      final userId = AppDependencies.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final activeRows = await AppDependencies.instance.client.rpc('list_my_rides_secure');
      if (activeRows is! List) throw StateError('تعذر التحقق من الرحلة النشطة');
      final hasActive = activeRows.any((row) => row is Map && row['driver_id'] == userId &&
          ['accepted', 'arrived', 'in_progress'].contains(row['status']));
      if (hasActive) {
        throw StateError('لا يمكن تسجيل الخروج أثناء وجود رحلة نشطة. أكمل الرحلة أولاً.');
      }
      // A driver must not remain advertised as available after explicitly logging out.
      if (_online) {
        final updated = await AppDependencies.instance.rideRepository.setDriverOnline(false);
        if (!updated) throw StateError('لم يؤكد الخادم إيقاف حالة الاتصال');
      }
      await AppDependencies.instance.client.auth.signOut();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر تسجيل الخروج بأمان: ${AppErrorMessage.from(error)}')),
        );
      }
    }
  }

  Future<void> _changeOnline(bool value) async {
    if (_onlineBusy) return;
    setState(() => _onlineBusy = true);
    try {
      final ok = await AppDependencies.instance.rideRepository.setDriverOnline(value);
      if (!ok) throw StateError('رفض الخادم تغيير حالة الاتصال');
      if (mounted) setState(() => _online = value);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تغيير الحالة: ${AppErrorMessage.from(error)}')));
    } finally {
      if (mounted) setState(() => _onlineBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final deps = AppDependencies.instance;
    final userId = deps.client.auth.currentUser?.id;
    if (userId == null) return const Scaffold(body: Center(child: Text('يرجى تسجيل الدخول')));
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('طلبات الرحلات'),
          actions: [
            if (!_onlineLoaded)
              const Padding(padding: EdgeInsets.all(14), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
            else
              Row(children: [Text(_online ? 'متصل' : 'غير متصل'), Switch(value: _online, onChanged: _onlineBusy ? null : _changeOnline)]),
            IconButton(
              tooltip: 'الإشعارات',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
              icon: const Icon(Icons.notifications_none),
            ),
            IconButton(tooltip: 'تسجيل الخروج', onPressed: _signOut, icon: const Icon(Icons.logout)),
          ],
        ),
        body: StreamBuilder<List<RideModel>>(
          stream: deps.rideRepository.watchDriverRides(userId),
          builder: (context, ownSnapshot) {
            if (ownSnapshot.hasError) return const _Info(message: 'تعذر تحميل رحلاتك. تحقق من الاتصال.');
            if (!ownSnapshot.hasData) return const Center(child: CircularProgressIndicator());
            final allOwnRows = ownSnapshot.data!;
            _syncLiveLocation(allOwnRows);
            final activeRows = allOwnRows.where((r) => r.status.isActiveForDriver).toList();
            final hasActiveRide = activeRows.isNotEmpty;
            return Column(children: [
              if (hasActiveRide)
                const MaterialBanner(
                  content: Text('لديك رحلة نشطة. يمكنك إكمالها قبل قبول طلب جديد.'),
                  leading: Icon(Icons.info_outline),
                  actions: [SizedBox.shrink()],
                ),
              Expanded(child: StreamBuilder<List<RideModel>>(
                stream: deps.rideRepository.watchAvailableRides(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) return const _Info(message: 'تعذر تحميل الطلبات المتاحة');
                  if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                  final rows = snapshot.data!;
                  if (rows.isEmpty) return const _Info(message: 'لا توجد طلبات متاحة الآن');
                  return ListView(children: [
                    const ListTile(title: Text('الطلبات المتاحة', style: TextStyle(fontWeight: FontWeight.bold))),
                    ...rows.map((ride) => _AvailableRideCard(
                      ride: ride,
                      userId: userId,
                      canAccept: _online && !hasActiveRide,
                    )),
                  ]);
                },
              )),
              const Divider(height: 1),
              Expanded(child: ListView(children: [
                const ListTile(title: Text('رحلتي النشطة', style: TextStyle(fontWeight: FontWeight.bold))),
                if (activeRows.isEmpty) const _Info(message: 'ليس لديك رحلة نشطة'),
                ...activeRows.map((ride) => _ActiveRideCard(ride: ride, userId: userId)),
              ])),
            ]);
          },
        ),
      ),
    );
  }

}

class _AvailableRideCard extends StatelessWidget {
  const _AvailableRideCard({required this.ride, required this.userId, required this.canAccept});
  final RideModel ride; final String userId; final bool canAccept;
  @override
  Widget build(BuildContext context) {
    if (!RideFlowPolicy.driverCanAccept(ride, userId)) return const SizedBox.shrink();
    final subtitle = canAccept
        ? 'الوجهة: ${ride.dropoffAddress}'
        : 'الوجهة: ${ride.dropoffAddress}\nأكمل رحلتك الحالية أو اتصل لتصبح متاحاً.';
    return Card(child: ListTile(
      title: Text(ride.pickupAddress),
      subtitle: Text(subtitle),
      trailing: IconButton(
        icon: const Icon(Icons.local_taxi),
        tooltip: 'قبول الرحلة',
        onPressed: canAccept
            ? () => _perform(context, () => AppDependencies.instance.rideRepository.acceptRide(ride.id))
            : null,
      ),
    ));
  }
}

class _ActiveRideCard extends StatelessWidget {
  const _ActiveRideCard({required this.ride, required this.userId});
  final RideModel ride; final String userId;
  @override
  Widget build(BuildContext context) {
    final next = RideFlowPolicy.nextDriverStatus(ride.status);
    return Card(child: ListTile(
      title: Text('من ${ride.pickupAddress} إلى ${ride.dropoffAddress}'),
      subtitle: Text(_driverStatus(ride.status)),
      trailing: Wrap(mainAxisSize: MainAxisSize.min, children: [
        IconButton(
          tooltip: 'الاتصال بالراكب',
          icon: const Icon(Icons.phone),
          onPressed: () => _callRider(context, ride.id),
        ),
        if (next != null)
          FilledButton(
            onPressed: () => _advance(context, ride.id, next),
            child: Text(switch(next) {
              RideStatus.arrived => 'وصلت',
              RideStatus.inProgress => 'بدء الرحلة',
              RideStatus.completed => 'إنهاء الرحلة',
              _ => 'تحديث',
            }),
          ),
      ]),
    ));
  }
}


Future<void> _callRider(BuildContext context, String rideId) async {
  try {
    final phone = await AppDependencies.instance.rideRepository.getRideContactPhone(rideId);
    final launched = await launchUrl(Uri(scheme: 'tel', path: phone));
    if (!launched) throw StateError('تعذر فتح تطبيق الاتصال');
  } catch (_) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('لا يمكن إظهار رقم الراكب أو الاتصال به في هذه الحالة.')),
    );
  }
}

Future<void> _advance(BuildContext context, String rideId, RideStatus next) async {
  try {
    if (next == RideStatus.arrived || next == RideStatus.inProgress) {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw StateError('فعّل خدمة الموقع GPS أولاً.');
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        throw StateError('يلزم السماح بالوصول إلى الموقع لتحديث موقع السائق.');
      }
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)),
      );
      final locationSaved = await AppDependencies.instance.rideRepository.updateDriverLocation(
        rideId: rideId, lat: position.latitude, lng: position.longitude,
      );
      if (!locationSaved) throw StateError('تعذر حفظ موقع السائق.');
    }
    final ok = await AppDependencies.instance.rideRepository.setRideStatus(rideId, next);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم تحديث حالة الرحلة' : 'رفضت قاعدة البيانات تحديث الحالة')));
  } catch (error) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحديث الرحلة: ${AppErrorMessage.from(error)}')));
  }
}

String _driverStatus(RideStatus s) => switch(s) {
  RideStatus.accepted => 'تم قبول الطلب', RideStatus.arrived => 'بانتظار بدء الرحلة',
  RideStatus.inProgress => 'الرحلة جارية', RideStatus.searching => 'طلب غير مسند',
  RideStatus.completed => 'مكتملة', RideStatus.cancelled => 'ملغاة',
};

Future<void> _perform(BuildContext context, Future<bool> Function() action) async {
  try {
    final ok = await action(); if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تم تنفيذ العملية' : 'رفضت قاعدة البيانات العملية')));
  } catch (_) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر تنفيذ العملية. تحقق من حالة الرحلة.')));
  }
}
class _Info extends StatelessWidget {
  const _Info({required this.message}); final String message;
  @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(message, textAlign: TextAlign.center)));
}
