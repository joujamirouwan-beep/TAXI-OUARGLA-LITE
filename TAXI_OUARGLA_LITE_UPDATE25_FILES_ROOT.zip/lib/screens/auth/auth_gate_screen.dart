import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../errors/app_error_message.dart';
import '../../routing/auth_wrapper.dart';
import '../../routing/profile_router.dart';
import '../rider_home_screen.dart';
import '../driver_home_screen.dart';
import '../admin_dashboard.dart';

class AuthGateScreen extends StatelessWidget {
  const AuthGateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final client = Supabase.instance.client;
    return AuthWrapper(
      client: client,
      signedOutBuilder: (_) => PhoneOtpScreen(onSignedIn: () {}),
      loadingBuilder: (_) => const _InfoScreen(message: 'جارٍ التحقق من الجلسة…'),
      errorBuilder: (_, error) => _InfoScreen(
        message: 'تعذر التحقق من الجلسة: ${AppErrorMessage.from(error)}',
      ),
      authenticatedBuilder: (context, user) => buildProfileRouter(
        context: context,
        client: client,
        user: user,
        pages: ProfileRouterBuilder(
          riderHome: (_) => const RiderHomeScreen(),
          driverHome: (_) => const DriverHomeScreen(),
          driverPending: (_) => const _InfoScreen(
            message: 'حساب السائق بانتظار اعتماد الإدارة. لن تظهر طلبات الرحلات قبل الاعتماد.',
          ),
          adminHome: (_) => const AdminDashboard(),
          loading: (_) => const _InfoScreen(message: 'جارٍ تحميل الملف الشخصي…'),
          missingProfile: (_) => const _InfoScreen(
            message: 'تم تسجيل الدخول لكن ملف الحساب غير موجود. يرجى مراجعة إعداد إنشاء الملف الشخصي في Supabase.',
          ),
          error: (_, error) => _InfoScreen(message: 'تعذر تحميل الملف الشخصي: ${AppErrorMessage.from(error)}'),
        ),
      ),
    );
  }
}

class PhoneOtpScreen extends StatefulWidget {
  const PhoneOtpScreen({super.key, required this.onSignedIn});
  final VoidCallback onSignedIn;
  @override
  State<PhoneOtpScreen> createState() => _PhoneOtpScreenState();
}

class _PhoneOtpScreenState extends State<PhoneOtpScreen> {
  final _phone = TextEditingController();
  final _otp = TextEditingController();
  final _name = TextEditingController();
  final _carModel = TextEditingController();
  final _plateNumber = TextEditingController();
  String _requestedRole = 'rider';
  bool _isNewAccount = true;
  bool _sent = false;
  bool _busy = false;

  String _e164(String value) {
    var v = value.trim().replaceAll(RegExp(r'[\s().-]'), '');
    if (v.startsWith('00')) v = '+${v.substring(2)}';
    if (v.startsWith('0')) v = '+213${v.substring(1)}';
    if (v.startsWith('213')) v = '+$v';
    if (!v.startsWith('+')) v = '+213$v';
    if (!RegExp(r'^\+213\d{9}$').hasMatch(v)) {
      throw const FormatException(
        'أدخل رقم هاتف جزائرياً صحيحاً: 0 متبوعاً بتسعة أرقام أو +213 متبوعاً بتسعة أرقام.',
      );
    }
    return v;
  }

  Future<void> _send() async {
    try {
      _e164(_phone.text);
    } on FormatException catch (e) {
      _message(e.message.toString());
      return;
    }
    if (_isNewAccount && _name.text.trim().length < 2) {
      _message('أدخل الاسم الكامل (حرفان على الأقل).');
      return;
    }
    if (_isNewAccount && _requestedRole == 'driver' &&
        (_carModel.text.trim().isEmpty || _plateNumber.text.trim().isEmpty)) {
      _message('أدخل نوع السيارة ورقم تسجيلها.');
      return;
    }

    setState(() => _busy = true);
    try {
      await Supabase.instance.client.auth.signInWithOtp(
        phone: _e164(_phone.text),
        shouldCreateUser: _isNewAccount,
        data: _isNewAccount
            ? {
                'full_name': _name.text.trim(),
                'role': _requestedRole,
                if (_requestedRole == 'driver') ...{
                  'car_model': _carModel.text.trim(),
                  'plate_number': _plateNumber.text.trim(),
                },
              }
            : const {},
      );
      if (mounted) setState(() => _sent = true);
    } catch (e) {
      _message('تعذر إرسال الرمز: ${AppErrorMessage.from(e)}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _verify() async {
    setState(() => _busy = true);
    try {
      await Supabase.instance.client.auth.verifyOTP(
        type: OtpType.sms,
        phone: _e164(_phone.text),
        token: _otp.text.trim(),
      );
      widget.onSignedIn();
    } catch (e) {
      _message('تعذر التحقق من الرمز: ${AppErrorMessage.from(e)}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String value) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
    }
  }

  @override
  void dispose() {
    _phone.dispose();
    _otp.dispose();
    _name.dispose();
    _carModel.dispose();
    _plateNumber.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.local_taxi, size: 76, color: Color(0xFFFFC107)),
              const SizedBox(height: 12),
              const Text('طاكسي ورڨلة لايت',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              if (!_sent) ...[
                DropdownButtonFormField<bool>(
                  value: _isNewAccount,
                  decoration: const InputDecoration(labelText: 'نوع العملية'),
                  items: const [
                    DropdownMenuItem(value: true, child: Text('إنشاء حساب جديد')),
                    DropdownMenuItem(value: false, child: Text('الدخول إلى حساب موجود')),
                  ],
                  onChanged: _busy ? null : (v) {
                    if (v != null) setState(() => _isNewAccount = v);
                  },
                ),
                if (_isNewAccount) ...[
                  const SizedBox(height: 12),
                  TextField(controller: _name,
                    decoration: const InputDecoration(labelText: 'الاسم الكامل')),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _requestedRole,
                    decoration: const InputDecoration(labelText: 'نوع الحساب'),
                    items: const [
                      DropdownMenuItem(value: 'rider', child: Text('راكب')),
                      DropdownMenuItem(value: 'driver', child: Text('سائق')),
                    ],
                    onChanged: _busy ? null : (v) {
                      if (v != null) setState(() => _requestedRole = v);
                    },
                  ),
                ],
                if (_isNewAccount && _requestedRole == 'driver') ...[
                  const SizedBox(height: 12),
                  TextField(controller: _carModel,
                    decoration: const InputDecoration(labelText: 'نوع السيارة')),
                  const SizedBox(height: 12),
                  TextField(controller: _plateNumber,
                    decoration: const InputDecoration(labelText: 'رقم تسجيل السيارة')),
                ],
                const SizedBox(height: 12),
                TextField(controller: _phone, keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(
                    labelText: 'رقم الهاتف الجزائري', hintText: '0XXXXXXXXX')),
                const SizedBox(height: 20),
                SizedBox(width: double.infinity, child: FilledButton(
                  onPressed: _busy ? null : _send,
                  child: _busy
                    ? const CircularProgressIndicator()
                    : const Text('إرسال رمز التحقق'),
                )),
                const SizedBox(height: 8),
                Text(
                  _isNewAccount
                      ? 'اختيار نوع الحساب يُطبّق عند إنشاء حساب جديد فقط. حساب السائق يبقى بانتظار اعتماد الإدارة.'
                      : 'أدخل رقم الهاتف المرتبط بحسابك لإرسال رمز الدخول. لا تُرسل بيانات إنشاء حساب جديد.',
                  textAlign: TextAlign.center,
                ),
              ] else ...[
                TextField(controller: _otp, keyboardType: TextInputType.number,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'رمز التحقق SMS')),
                const SizedBox(height: 20),
                SizedBox(width: double.infinity, child: FilledButton(
                  onPressed: _busy ? null : _verify,
                  child: _busy
                    ? const CircularProgressIndicator()
                    : const Text('تأكيد الرمز والدخول'),
                )),
              ],
            ]),
          ),
        ),
      ),
    ),
  );
}

class _InfoScreen extends StatelessWidget {
  const _InfoScreen({required this.message, this.actionLabel, this.onAction});
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('طاكسي ورڨلة لايت')),
      body: Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(message, textAlign: TextAlign.center),
          if (actionLabel != null) ...[
            const SizedBox(height: 16),
            FilledButton(onPressed: onAction, child: Text(actionLabel!)),
          ],
          const SizedBox(height: 12),
          TextButton(onPressed: () => Supabase.instance.client.auth.signOut(), child: const Text('تسجيل الخروج')),
        ]),
      )),
    ),
  );
}
