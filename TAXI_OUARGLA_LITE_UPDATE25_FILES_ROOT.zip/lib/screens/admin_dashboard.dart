import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../errors/app_error_message.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final SupabaseClient _db = Supabase.instance.client;
  late Future<List<Map<String, dynamic>>> _pendingDriversFuture;
  final Set<String> _processingDrivers = <String>{};

  @override
  void initState() {
    super.initState();
    _pendingDriversFuture = _loadPendingDrivers();
  }

  Future<List<Map<String, dynamic>>> _loadPendingDrivers() async {
    final result = await _db.rpc('admin_list_pending_drivers_secure');
    if (result is! List) throw StateError('استجابة غير صحيحة من الخادم');
    return result
        .map((row) => Map<String, dynamic>.from(row as Map))
        .toList(growable: false);
  }

  Future<void> _refreshDrivers() async {
    setState(() => _pendingDriversFuture = _loadPendingDrivers());
  }

  Future<void> _approveDriver(Map<String, dynamic> driver) async {
    final id = driver['id']?.toString();
    if (id == null || id.isEmpty || _processingDrivers.contains(id)) return;

    setState(() => _processingDrivers.add(id));
    try {
      final result = await _db.rpc(
        'admin_set_driver_verification_secure',
        params: {'p_driver_id': id, 'p_verified': true},
      );
      if (result != true) throw Exception('لم يؤكد الخادم عملية الاعتماد');

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم اعتماد ${driver['full_name'] ?? 'السائق'} بنجاح')),
      );
      _refreshDrivers();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر اعتماد السائق: ${AppErrorMessage.from(e)}')),
        );
      }
    } finally {
      if (mounted) setState(() => _processingDrivers.remove(id));
    }
  }

  Stream<List<Map<String, dynamic>>> _ridesStream() {
    return _adminRidesPolling();
  }

  Stream<List<Map<String, dynamic>>> _adminRidesPolling() async* {
    while (true) {
      final result = await _db.rpc('admin_list_rides_secure');
      if (result is! List) throw StateError('استجابة غير صحيحة من الخادم');
      yield result.map((row) => Map<String, dynamic>.from(row as Map)).toList(growable: false);
      await Future<void>.delayed(const Duration(seconds: 8));
    }
  }

  String _status(String? value) {
    switch (value) {
      case 'searching': return 'قيد البحث عن سائق';
      case 'accepted': return 'قبلها السائق';
      case 'arrived': return 'السائق وصل';
      case 'in_progress': return 'الرحلة جارية';
      case 'completed': return 'مكتملة';
      case 'cancelled': return 'ملغاة';
      default: return value ?? 'غير معروف';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('إدارة طاكسي ورڨلة لايت'),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.verified_user), text: 'اعتماد السائقين'),
                Tab(icon: Icon(Icons.route), text: 'مراقبة الرحلات'),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'تحديث طلبات السائقين',
                onPressed: () => _refreshDrivers(),
                icon: const Icon(Icons.refresh),
              ),
              IconButton(
                tooltip: 'تسجيل الخروج',
                onPressed: () => _db.auth.signOut(),
                icon: const Icon(Icons.logout),
              ),
            ],
          ),
          body: TabBarView(
            children: [
              _buildPendingDrivers(),
              _buildRides(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPendingDrivers() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _pendingDriversFuture,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('تعذر تحميل السائقين: ${AppErrorMessage.from(snapshot.error!)}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final drivers = snapshot.data!;
        if (drivers.isEmpty) {
          return const Center(child: Text('لا توجد طلبات اعتماد معلّقة.'));
        }
        return RefreshIndicator(
          onRefresh: _refreshDrivers,
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: drivers.length,
            itemBuilder: (context, index) {
              final driver = drivers[index];
              final id = driver['id'].toString();
              final busy = _processingDrivers.contains(id);
              return Card(
                child: ListTile(
                  title: Text(driver['full_name']?.toString() ?? 'سائق بدون اسم'),
                  subtitle: Text(
                    'السيارة: ${driver['car_model'] ?? 'غير محدد'}\n'
                    'رقم التسجيل: ${driver['plate_number'] ?? 'غير محدد'}',
                  ),
                  isThreeLine: true,
                  trailing: FilledButton(
                    onPressed: busy ? null : () => _approveDriver(driver),
                    child: busy
                      ? const SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('اعتماد'),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildRides() {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _ridesStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('تعذر تحميل الرحلات: ${AppErrorMessage.from(snapshot.error!)}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final rides = snapshot.data!;
        if (rides.isEmpty) {
          return const Center(child: Text('لا توجد رحلات مسجلة.'));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: rides.length,
          itemBuilder: (context, index) {
            final ride = rides[index];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.local_taxi),
                title: Text(
                  '${ride['pickup_address'] ?? 'انطلاق غير محدد'} ← '
                  '${ride['dropoff_address'] ?? 'وجهة غير محددة'}',
                ),
                subtitle: Text(
                  'الحالة: ${_status(ride['status']?.toString())}\n'
                  'معرّف الرحلة: ${ride['id']}',
                ),
                isThreeLine: true,
              ),
            );
          },
        );
      },
    );
  }
}
