import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import '../errors/app_error_message.dart';
import '../services/trip_service.dart';
import '../widgets/osm_ride_map.dart';

class RideTrackingScreen extends StatefulWidget {
  const RideTrackingScreen({super.key, required this.rideId});
  final String rideId;

  @override
  State<RideTrackingScreen> createState() => _RideTrackingScreenState();
}

class _RideTrackingScreenState extends State<RideTrackingScreen> {
  final _service = TripService();
  int _rating = 5;
  bool _busy = false;

  String _statusLabel(String status) {
    switch (status) {
      case 'searching': return 'نبحث عن سائق قريب';
      case 'accepted': return 'تم قبول الرحلة';
      case 'arrived': return 'السائق وصل إلى نقطة الانطلاق';
      case 'in_progress': return 'الرحلة جارية';
      case 'completed': return 'اكتملت الرحلة';
      case 'cancelled': return 'تم إلغاء الطلب';
      default: return status;
    }
  }

  Future<void> _cancel() async {
    setState(() => _busy = true);
    try {
      await _service.cancelSearchingTrip(widget.rideId);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر إلغاء الطلب: ${AppErrorMessage.from(e)}')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _callOtherParty() async {
    setState(() => _busy = true);
    try {
      final phone = await _service.getRideContactPhone(widget.rideId);
      final uri = Uri(scheme: 'tel', path: phone);
      if (!await launchUrl(uri)) {
        throw StateError('تعذر فتح تطبيق الاتصال');
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر الاتصال: ${AppErrorMessage.from(error)}')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendRating() async {
    setState(() => _busy = true);
    try {
      await _service.rateCompletedTrip(rideId: widget.rideId, rating: _rating);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر إرسال التقييم: ${AppErrorMessage.from(e)}')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('متابعة الرحلة')),
        body: StreamBuilder<List<Map<String, dynamic>>>(
          stream: _service.streamRide(widget.rideId),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('تعذر تحميل الرحلة: ${AppErrorMessage.from(snapshot.error!)}'));
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            final ride = snapshot.data!.first;
            final status = ride['status'] as String? ?? 'unknown';
            final pickup = LatLng(
              (ride['pickup_lat'] as num).toDouble(),
              (ride['pickup_lng'] as num).toDouble(),
            );
            final dropoff = LatLng(
              (ride['dropoff_lat'] as num).toDouble(),
              (ride['dropoff_lng'] as num).toDouble(),
            );
            final hasDriverLocation =
                ride['driver_lat'] != null && ride['driver_lng'] != null;
            final driver = hasDriverLocation
                ? LatLng(
                    (ride['driver_lat'] as num).toDouble(),
                    (ride['driver_lng'] as num).toDouble(),
                  )
                : null;

            return Column(
              children: [
                Expanded(
                  child: OsmRideMap(
                    initialCenter: driver ?? pickup,
                    initialZoom: 14,
                    pickup: pickup,
                    dropoff: dropoff,
                    driver: driver,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _statusLabel(status),
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text('الانطلاق: ${ride['pickup_address']}'),
                      Text('الوجهة: ${ride['dropoff_address']}'),
                      const SizedBox(height: 8),
                      const Text('الاتفاق على الأجرة يتم مباشرة بين الراكب والسائق خارج التطبيق.'),
                      if (['accepted', 'arrived', 'in_progress'].contains(status))
                        OutlinedButton.icon(
                          onPressed: _busy ? null : _callOtherParty,
                          icon: const Icon(Icons.phone),
                          label: const Text('الاتصال بالطرف الآخر'),
                        ),
                      if (status == 'searching') ...[
                        const SizedBox(height: 12),
                        OutlinedButton(
                          onPressed: _busy ? null : _cancel,
                          child: const Text('إلغاء طلب البحث'),
                        ),
                      ],
                      if (status == 'completed' && ride['rating'] == null) ...[
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (i) => IconButton(
                            onPressed: _busy ? null : () => setState(() => _rating = i + 1),
                            icon: Icon(i < _rating ? Icons.star : Icons.star_border),
                          )),
                        ),
                        FilledButton(
                          onPressed: _busy ? null : _sendRating,
                          child: const Text('إرسال التقييم'),
                        ),
                      ],
                      if (status == 'cancelled')
                        const Text('يمكنك العودة وطلب رحلة جديدة.'),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
