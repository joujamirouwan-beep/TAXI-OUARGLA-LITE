import 'package:flutter/material.dart';

import '../app/app_dependencies.dart';
import '../models/app_notification.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<List<AppNotification>> _future;
  bool _markingAll = false;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _future = AppDependencies.instance.notificationService.fetchLatest();
  }

  Future<void> _markOne(AppNotification notification) async {
    if (notification.isRead) return;
    try {
      await AppDependencies.instance.notificationService.markRead(notification.id);
      if (!mounted) return;
      setState(_reload);
    } catch (_) {
      _message('تعذر تحديث الإشعار. تحقق من الاتصال.');
    }
  }

  Future<void> _markAll(List<AppNotification> notifications) async {
    if (_markingAll || !notifications.any((item) => !item.isRead)) return;
    setState(() => _markingAll = true);
    try {
      await AppDependencies.instance.notificationService.markAllRead();
      if (!mounted) return;
      setState(_reload);
    } catch (_) {
      _message('تعذر تحديث الإشعارات. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _markingAll = false);
    }
  }

  void _message(String value) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('الإشعارات'),
            actions: [
              IconButton(
                tooltip: 'تحديث',
                onPressed: () => setState(_reload),
                icon: const Icon(Icons.refresh),
              ),
            ],
          ),
          body: FutureBuilder<List<AppNotification>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('تعذر تحميل الإشعارات.'),
                    TextButton(onPressed: () => setState(_reload), child: const Text('إعادة المحاولة')),
                  ]),
                );
              }
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final notifications = snapshot.data!;
              if (notifications.isEmpty) {
                return const Center(child: Text('لا توجد إشعارات حتى الآن.'));
              }
              return Column(children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: _markingAll ? null : () => _markAll(notifications),
                    icon: _markingAll
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.done_all),
                    label: const Text('تعليم الكل كمقروء'),
                  ),
                ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () async => setState(_reload),
                    child: ListView.separated(
                      physics: const AlwaysScrollableScrollPhysics(),
                      itemCount: notifications.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final item = notifications[index];
                        return ListTile(
                          leading: CircleAvatar(
                            child: Icon(item.isRead ? Icons.notifications_none : Icons.notifications_active),
                          ),
                          title: Text(item.title, style: TextStyle(fontWeight: item.isRead ? FontWeight.normal : FontWeight.bold)),
                          subtitle: Text('${item.body}\n${_formatDate(item.createdAt)}'),
                          isThreeLine: true,
                          trailing: item.isRead ? null : const Icon(Icons.circle, size: 9, color: Colors.amber),
                          onTap: () => _markOne(item),
                        );
                      },
                    ),
                  ),
                ),
              ]);
            },
          ),
        ),
      );

  String _formatDate(DateTime value) {
    final local = value.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(local.day)}/${two(local.month)}/${local.year} - ${two(local.hour)}:${two(local.minute)}';
  }
}
