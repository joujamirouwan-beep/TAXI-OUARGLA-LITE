$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
function Require($Condition, $Message) { if (-not $Condition) { throw $Message } }
Require (Get-Command flutter -ErrorAction SilentlyContinue) 'Flutter SDK غير مثبت أو غير موجود في PATH.'
Require (Get-Command java -ErrorAction SilentlyContinue) 'JDK 17 مطلوب لبناء Android مع AGP 8.3.2.'
$JavaVersion = (& java -version 2>&1 | Out-String)
Require ($JavaVersion -match 'version "17([.]|")') 'إصدار Java الحالي ليس JDK 17؛ استخدم JDK 17 مع Gradle 8.4.'
Require (Test-Path 'android/gradlew.bat') 'android/gradlew.bat مفقود؛ استعد Android Wrapper الأصلي من مشروع المبرمج.'
Require (Test-Path 'android/gradle/wrapper/gradle-wrapper.jar') 'gradle-wrapper.jar مفقود.'
Require (Test-Path 'android/key.properties') 'ملف android/key.properties مفقود؛ استخدم مفتاح التوقيع الأصلي.'
$Signing = Get-Content 'android/key.properties' -Raw
foreach ($Key in @('storeFile','storePassword','keyAlias','keyPassword')) {
  Require ($Signing -match "(?m)^$Key=.+$") "قيمة $Key مفقودة من android/key.properties."
  Require ($Signing -notmatch "(?m)^$Key=REPLACE_LOCALLY$") "استبدل القيمة التجريبية $Key محلياً."
}
Require ($env:SUPABASE_URL) 'عيّن SUPABASE_URL.'
Require ($env:SUPABASE_ANON_KEY) 'عيّن SUPABASE_ANON_KEY.'
Require ($env:BUILD_NUMBER -match '^[1-9][0-9]*$') 'عيّن BUILD_NUMBER أعلى من آخر إصدار على Google Play.'
flutter --version
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build appbundle --release --build-name=3.10.1 --build-number=$env:BUILD_NUMBER --dart-define="SUPABASE_URL=$env:SUPABASE_URL" --dart-define="SUPABASE_ANON_KEY=$env:SUPABASE_ANON_KEY"
$Aab = 'build/app/outputs/bundle/release/app-release.aab'
Require (Test-Path $Aab) 'لم يتم إنشاء ملف AAB.'
Get-Item $Aab | Format-List FullName, Length, LastWriteTime
Get-FileHash $Aab -Algorithm SHA256
$JarSigner = Get-Command jarsigner -ErrorAction SilentlyContinue
Require $JarSigner 'jarsigner غير موجود ضمن JDK.'
& $JarSigner.Source -verify $Aab
Require ($LASTEXITCODE -eq 0) 'فشل التحقق من توقيع AAB.'
