package com.taxiouargla.lite

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
