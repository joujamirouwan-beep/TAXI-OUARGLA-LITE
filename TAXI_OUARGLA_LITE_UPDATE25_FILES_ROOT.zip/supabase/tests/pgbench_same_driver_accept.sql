-- pgbench script: race one driver accepting ONE designated searching ride.
-- Required variables: driver_id, ride_id
-- Run two pgbench processes concurrently with different ride_id values.
SELECT set_config('request.jwt.claim.sub', :'driver_id', false);
SELECT public.accept_ride_secure(:'ride_id'::uuid);
