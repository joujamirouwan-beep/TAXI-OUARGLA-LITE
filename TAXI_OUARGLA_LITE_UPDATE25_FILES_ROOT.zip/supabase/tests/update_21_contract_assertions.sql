-- TAXI OUARGLA LITE / UPDATE 21
-- Read-only catalog and data invariants. Run against STAGING only.
-- psql -v ON_ERROR_STOP=1 "$STAGING_DATABASE_URL" -f this_file

DO $test$
DECLARE
  v_pred text;
  v_count integer;
BEGIN
  -- Exact six-state contract.
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.rides'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%searching%accepted%arrived%in_progress%completed%cancelled%'
  ) THEN
    RAISE EXCEPTION 'FAIL: six-state rides CHECK constraint missing';
  END IF;

  -- Unique active rider index must include searching + all assigned active states.
  SELECT pg_get_expr(i.indpred, i.indrelid) INTO v_pred
  FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
  WHERE i.indrelid='public.rides'::regclass
    AND c.relname='uq_rides_one_active_trip_per_rider' AND i.indisunique;
  IF v_pred IS NULL OR NOT (v_pred ILIKE '%searching%' AND v_pred ILIKE '%accepted%' AND v_pred ILIKE '%arrived%' AND v_pred ILIKE '%in_progress%') THEN
    RAISE EXCEPTION 'FAIL: rider unique active index predicate incorrect: %', v_pred;
  END IF;

  -- Unique active driver index excludes searching, includes assigned active states.
  SELECT pg_get_expr(i.indpred, i.indrelid) INTO v_pred
  FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
  WHERE i.indrelid='public.rides'::regclass
    AND c.relname='uq_rides_one_active_trip_per_driver' AND i.indisunique;
  IF v_pred IS NULL OR NOT (v_pred ILIKE '%accepted%' AND v_pred ILIKE '%arrived%' AND v_pred ILIKE '%in_progress%') OR v_pred ILIKE '%searching%' THEN
    RAISE EXCEPTION 'FAIL: driver unique active index predicate incorrect: %', v_pred;
  END IF;

  -- All canonical RPC signatures must exist exactly once.
  SELECT count(*) INTO v_count
  FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
  WHERE n.nspname='public' AND (
    (p.proname='create_ride_secure' AND oidvectortypes(p.proargtypes)='text, double precision, double precision, text, double precision, double precision') OR
    (p.proname='accept_ride_secure' AND oidvectortypes(p.proargtypes)='uuid') OR
    (p.proname='set_ride_status_secure' AND oidvectortypes(p.proargtypes)='uuid, text') OR
    (p.proname='set_driver_online_secure' AND oidvectortypes(p.proargtypes)='boolean') OR
    (p.proname='admin_set_driver_verification_secure' AND oidvectortypes(p.proargtypes)='uuid, boolean') OR
    (p.proname='get_ride_contact_phone_secure' AND oidvectortypes(p.proargtypes)='uuid')
  );
  IF v_count <> 6 THEN RAISE EXCEPTION 'FAIL: expected 6 canonical RPC signatures, found %', v_count; END IF;

  -- Protected fields cannot be changed directly by authenticated clients.
  IF has_column_privilege('authenticated','public.profiles','is_verified','UPDATE')
     OR has_column_privilege('authenticated','public.profiles','is_online','UPDATE')
     OR has_column_privilege('authenticated','public.profiles','phone','SELECT') THEN
    RAISE EXCEPTION 'FAIL: protected profiles column privilege is exposed';
  END IF;

  -- Clients cannot write rides directly; all changes pass through RPCs.
  IF has_table_privilege('authenticated','public.rides','INSERT')
     OR has_table_privilege('authenticated','public.rides','UPDATE')
     OR has_table_privilege('authenticated','public.rides','DELETE') THEN
    RAISE EXCEPTION 'FAIL: authenticated has direct rides DML';
  END IF;

  RAISE NOTICE 'PASS: UPDATE 21 catalog and invariant assertions';
END
$test$;

-- Existing-data invariant checks. These return zero rows when healthy.
SELECT rider_id, count(*) AS active_count
FROM public.rides
WHERE status IN ('searching','accepted','arrived','in_progress')
GROUP BY rider_id HAVING count(*) > 1;

SELECT driver_id, count(*) AS active_count
FROM public.rides
WHERE driver_id IS NOT NULL
  AND status IN ('accepted','arrived','in_progress')
GROUP BY driver_id HAVING count(*) > 1;
