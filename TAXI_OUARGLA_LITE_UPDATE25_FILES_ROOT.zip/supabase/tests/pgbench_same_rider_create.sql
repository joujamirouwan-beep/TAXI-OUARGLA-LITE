-- pgbench script: race two or more create attempts for ONE rider.
-- Required pgbench variables: rider_id
-- Each successful transaction creates a searching ride; later attempts
-- should be rejected by the profile lock / active-ride guard.
SELECT set_config('request.jwt.claim.sub', :'rider_id', false);
SELECT public.create_ride_secure(
  'UPDATE21 test pickup', 31.9500, 5.3200,
  'UPDATE21 test destination', 31.9600, 5.3300
);
