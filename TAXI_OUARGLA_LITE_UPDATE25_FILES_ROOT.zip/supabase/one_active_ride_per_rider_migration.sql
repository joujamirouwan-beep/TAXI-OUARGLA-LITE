-- TAXI OUARGLA LITE V3.6
-- Enforce at database level: one active ride per rider.
-- Safe for an existing V2 database. Run in Supabase SQL Editor.
-- Active states: searching, accepted, arrived, in_progress.

BEGIN;

-- Give a readable diagnostic instead of an opaque unique-index failure
-- if legacy data already contains multiple active rides for one rider.
DO $$
DECLARE
  v_duplicates TEXT;
BEGIN
  SELECT string_agg(
    format('%s (%s active rides)', rider_id, active_count),
    ', '
  )
  INTO v_duplicates
  FROM (
    SELECT rider_id, count(*) AS active_count
    FROM public.rides
    WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress')
    GROUP BY rider_id
    HAVING count(*) > 1
    ORDER BY rider_id
    LIMIT 20
  ) AS duplicate_riders;

  IF v_duplicates IS NOT NULL THEN
    RAISE EXCEPTION
      'Cannot enforce one active ride per rider. Resolve these duplicates first: %',
      v_duplicates
      USING HINT = 'Keep only one active ride per rider; mark other erroneous active rows cancelled after reviewing them.';
  END IF;
END;
$$;

CREATE UNIQUE INDEX IF NOT EXISTS one_active_ride_per_rider
  ON public.rides (rider_id)
  WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress');

COMMIT;
