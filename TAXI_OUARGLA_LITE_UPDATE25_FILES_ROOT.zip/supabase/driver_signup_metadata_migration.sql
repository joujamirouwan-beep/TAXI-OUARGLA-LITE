-- TAXI OUARGLA LITE - Driver signup metadata migration
-- Apply AFTER taxi_ouargla_lite_supabase_schema_v2.sql.
-- New phone signups may send full_name, role, car_model and plate_number
-- as Supabase Auth user metadata. Existing accounts are not changed.

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_name TEXT;
  v_role TEXT;
  v_car_model TEXT;
  v_plate_number TEXT;
BEGIN
  v_name := COALESCE(
    NULLIF(btrim(NEW.raw_user_meta_data ->> 'full_name'), ''),
    'مستخدم جديد'
  );

  -- Never allow user metadata to create an admin account.
  v_role := CASE
    WHEN NEW.raw_user_meta_data ->> 'role' = 'driver' THEN 'driver'
    ELSE 'rider'
  END;

  IF v_role = 'driver' THEN
    v_car_model := NULLIF(btrim(NEW.raw_user_meta_data ->> 'car_model'), '');
    v_plate_number := NULLIF(btrim(NEW.raw_user_meta_data ->> 'plate_number'), '');

    IF v_car_model IS NULL OR v_plate_number IS NULL THEN
      RAISE EXCEPTION 'يجب إدخال نوع السيارة ورقم تسجيلها للسائق';
    END IF;
  ELSE
    v_car_model := NULL;
    v_plate_number := NULL;
  END IF;

  INSERT INTO public.profiles (
    id, full_name, phone, role, car_model, plate_number
  )
  VALUES (
    NEW.id,
    v_name,
    NULLIF(NEW.phone, ''),
    v_role,
    v_car_model,
    v_plate_number
  );

  RETURN NEW;
END;
$$;
