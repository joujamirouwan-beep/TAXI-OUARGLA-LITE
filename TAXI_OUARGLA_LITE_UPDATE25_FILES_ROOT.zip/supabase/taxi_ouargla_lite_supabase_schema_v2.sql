-- ============================================================
-- TAXI OUARGLA LITE
-- Supabase secure schema V2 - direct price agreement outside app
-- Fresh-project installation script.
--
-- IMPORTANT:
-- 1) This is for a NEW/EMPTY Supabase project, not an in-place migration.
-- 2) Do not expose the service_role key in Flutter.
-- 3) No fare calculation, fare offers, negotiated-price field, wallet,
--    commission, or automatic fee is included.
-- 4) Admin bootstrap instructions are at the end of this file.
-- ============================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;

-- ------------------------------------------------------------
-- 1. Profiles
-- A profile is created automatically after Supabase Auth signup.
-- Users may choose rider/driver in signup metadata, never admin.
-- ------------------------------------------------------------

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL
    CHECK (char_length(btrim(full_name)) BETWEEN 2 AND 100),
  phone TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'rider'
    CHECK (role IN ('rider', 'driver', 'admin')),
  is_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_online BOOLEAN NOT NULL DEFAULT FALSE,
  car_model TEXT,
  plate_number TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT driver_fields_only_for_drivers CHECK (
    role = 'driver' OR (car_model IS NULL AND plate_number IS NULL)
  )
);

-- ------------------------------------------------------------
-- 2. Rides
-- The app records pickup/dropoff only. Price is agreed verbally
-- or directly between the two people outside the app.
-- ------------------------------------------------------------

CREATE TABLE public.rides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rider_id UUID NOT NULL REFERENCES public.profiles(id),
  driver_id UUID REFERENCES public.profiles(id),
  pickup_address TEXT NOT NULL
    CHECK (char_length(btrim(pickup_address)) BETWEEN 2 AND 300),
  pickup_lat DOUBLE PRECISION NOT NULL
    CHECK (pickup_lat BETWEEN -90 AND 90),
  pickup_lng DOUBLE PRECISION NOT NULL
    CHECK (pickup_lng BETWEEN -180 AND 180),
  dropoff_address TEXT NOT NULL
    CHECK (char_length(btrim(dropoff_address)) BETWEEN 2 AND 300),
  dropoff_lat DOUBLE PRECISION NOT NULL
    CHECK (dropoff_lat BETWEEN -90 AND 90),
  dropoff_lng DOUBLE PRECISION NOT NULL
    CHECK (dropoff_lng BETWEEN -180 AND 180),
  status TEXT NOT NULL DEFAULT 'searching'
    CHECK (status IN (
      'searching', 'accepted', 'arrived',
      'in_progress', 'completed', 'cancelled'
    )),
  driver_lat DOUBLE PRECISION
    CHECK (driver_lat IS NULL OR driver_lat BETWEEN -90 AND 90),
  driver_lng DOUBLE PRECISION
    CHECK (driver_lng IS NULL OR driver_lng BETWEEN -180 AND 180),
  rating SMALLINT
    CHECK (rating IS NULL OR rating BETWEEN 1 AND 5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT rides_driver_required_for_assigned_status CHECK (
    (status IN ('searching', 'cancelled') AND driver_id IS NULL)
    OR
    (status IN ('accepted', 'arrived', 'in_progress', 'completed')
      AND driver_id IS NOT NULL)
  ),
  CONSTRAINT rides_driver_location_pair CHECK (
    (driver_lat IS NULL AND driver_lng IS NULL)
    OR
    (driver_lat IS NOT NULL AND driver_lng IS NOT NULL)
  )
);

CREATE INDEX rides_rider_created_idx
  ON public.rides (rider_id, created_at DESC);

CREATE INDEX rides_driver_created_idx
  ON public.rides (driver_id, created_at DESC);

CREATE INDEX rides_searching_created_idx
  ON public.rides (created_at DESC)
  WHERE status = 'searching';

-- Database guarantee: at most one active ride per driver.
CREATE UNIQUE INDEX one_active_ride_per_driver
  ON public.rides (driver_id)
  WHERE driver_id IS NOT NULL
    AND status IN ('accepted', 'arrived', 'in_progress');

-- Database guarantee: at most one active ride per rider.
CREATE UNIQUE INDEX one_active_ride_per_rider
  ON public.rides (rider_id)
  WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress');

-- ------------------------------------------------------------
-- 3. Updated-at trigger
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = pg_catalog
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trg_rides_updated_at
BEFORE UPDATE ON public.rides
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ------------------------------------------------------------
-- 4. Automatic profile creation from Supabase Auth
-- role metadata can only become rider or driver; never admin.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_name TEXT;
  v_role TEXT;
  v_car_model TEXT;
  v_plate_number TEXT;
BEGIN
  v_name := COALESCE(
    NULLIF(btrim(NEW.raw_user_meta_data ->> 'full_name'), ''),
    'مستخدم جديد'
  );

  -- The client may request only rider or driver. Admin is never accepted
  -- from public signup metadata; administrator assignment is manual.
  v_role := CASE
    WHEN NEW.raw_user_meta_data ->> 'role' = 'driver' THEN 'driver'
    ELSE 'rider'
  END;

  v_car_model := NULLIF(btrim(NEW.raw_user_meta_data ->> 'car_model'), '');
  v_plate_number := NULLIF(btrim(NEW.raw_user_meta_data ->> 'plate_number'), '');

  INSERT INTO public.profiles (
    id, full_name, phone, role, car_model, plate_number
  )
  VALUES (
    NEW.id, v_name, NULLIF(NEW.phone, ''), v_role,
    CASE WHEN v_role = 'driver' THEN v_car_model ELSE NULL END,
    CASE WHEN v_role = 'driver' THEN v_plate_number ELSE NULL END
  );

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created_profile
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- ------------------------------------------------------------
-- 5. Security helper functions
-- SECURITY DEFINER avoids RLS recursion while reading profiles.
-- Every function pins search_path and qualifies table names.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles p
    WHERE p.id = auth.uid()
      AND p.role = 'admin'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_eligible_driver()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles p
    WHERE p.id = auth.uid()
      AND p.role = 'driver'
      AND p.is_verified IS TRUE
      AND p.is_online IS TRUE
  );
$$;

-- ------------------------------------------------------------
-- 6. RLS
-- No direct client UPDATE/DELETE on rides.
-- Sensitive operations are available only through guarded RPCs.
-- ------------------------------------------------------------

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rides ENABLE ROW LEVEL SECURITY;

CREATE POLICY profiles_read_self_related_admin
ON public.profiles
FOR SELECT
TO authenticated
USING (
  id = auth.uid()
  OR public.is_admin_user()
  OR EXISTS (
    SELECT 1
    FROM public.rides r
    WHERE (
      (r.rider_id = auth.uid() AND r.driver_id = profiles.id)
      OR
      (r.driver_id = auth.uid() AND r.rider_id = profiles.id)
    )
    AND r.status IN ('accepted', 'arrived', 'in_progress', 'completed')
  )
);

CREATE POLICY profiles_update_safe_self
ON public.profiles
FOR UPDATE
TO authenticated
USING (
  id = auth.uid()
  AND role IN ('rider', 'driver')
)
WITH CHECK (
  id = auth.uid()
  AND role IN ('rider', 'driver')
);

CREATE POLICY rides_read_participants_admin_and_available_drivers
ON public.rides
FOR SELECT
TO authenticated
USING (
  rider_id = auth.uid()
  OR driver_id = auth.uid()
  OR public.is_admin_user()
  OR (status = 'searching' AND public.is_eligible_driver())
);

-- ------------------------------------------------------------
-- 7. Table privileges
-- Profiles: users can read allowed rows and edit only safe fields.
-- Rides: clients read permitted rows; all writes use guarded RPCs.
-- ------------------------------------------------------------

REVOKE ALL ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
REVOKE SELECT (phone) ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.rides FROM PUBLIC, anon, authenticated;

-- Do not grant SELECT on phone. Contact numbers are exposed only by a
-- participant-checked RPC while a ride is active.
GRANT SELECT (
  id, full_name, role, is_verified, is_online,
  car_model, plate_number, created_at, updated_at
) ON TABLE public.profiles TO authenticated;
GRANT UPDATE (full_name, car_model, plate_number)
  ON TABLE public.profiles TO authenticated;

GRANT SELECT ON TABLE public.rides TO authenticated;
-- Ride creation and all updates go through guarded SECURITY DEFINER RPCs.
REVOKE INSERT, UPDATE, DELETE ON TABLE public.rides FROM PUBLIC, anon, authenticated;


-- ------------------------------------------------------------
-- 8a. Secure ride creation. The client cannot set status/driver/rating.
-- The profile lock serializes a rider's concurrent create attempts.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_ride_secure(
  p_pickup_address TEXT,
  p_pickup_lat DOUBLE PRECISION,
  p_pickup_lng DOUBLE PRECISION,
  p_dropoff_address TEXT,
  p_dropoff_lat DOUBLE PRECISION,
  p_dropoff_lng DOUBLE PRECISION
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_role TEXT;
  v_ride public.rides%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  IF p_pickup_address IS NULL OR char_length(btrim(p_pickup_address)) NOT BETWEEN 2 AND 300
     OR p_dropoff_address IS NULL OR char_length(btrim(p_dropoff_address)) NOT BETWEEN 2 AND 300 THEN
    RAISE EXCEPTION 'يرجى إدخال عنوان صحيح للانطلاق والوجهة';
  END IF;

  IF p_pickup_lat IS NULL OR p_pickup_lat NOT BETWEEN -90 AND 90
     OR p_pickup_lng IS NULL OR p_pickup_lng NOT BETWEEN -180 AND 180
     OR p_dropoff_lat IS NULL OR p_dropoff_lat NOT BETWEEN -90 AND 90
     OR p_dropoff_lng IS NULL OR p_dropoff_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'إحداثيات الموقع غير صحيحة';
  END IF;

  SELECT p.role INTO v_role
  FROM public.profiles p
  WHERE p.id = v_uid
  FOR UPDATE;

  IF NOT FOUND OR v_role <> 'rider' THEN
    RAISE EXCEPTION 'إنشاء طلب الرحلة متاح للركاب فقط';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.rides r
    WHERE r.rider_id = v_uid
      AND r.status IN ('searching', 'accepted', 'arrived', 'in_progress')
  ) THEN
    RAISE EXCEPTION 'لديك طلب رحلة نشط بالفعل';
  END IF;

  INSERT INTO public.rides (
    rider_id, pickup_address, pickup_lat, pickup_lng,
    dropoff_address, dropoff_lat, dropoff_lng
  ) VALUES (
    v_uid, btrim(p_pickup_address), p_pickup_lat, p_pickup_lng,
    btrim(p_dropoff_address), p_dropoff_lat, p_dropoff_lng
  ) RETURNING * INTO v_ride;

  RETURN jsonb_build_object(
    'id', v_ride.id,
    'status', v_ride.status,
    'created_at', v_ride.created_at
  );
END;
$$;

-- ------------------------------------------------------------
-- 8. Accept ride securely
-- Serializes a driver's accept attempts by locking their profile,
-- and serializes competing drivers by locking the ride row.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.accept_ride_secure(p_ride_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_role TEXT;
  v_verified BOOLEAN;
  v_online BOOLEAN;
  v_status TEXT;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  SELECT p.role, p.is_verified, p.is_online
  INTO v_role, v_verified, v_online
  FROM public.profiles p
  WHERE p.id = v_uid
  FOR UPDATE;

  IF NOT FOUND
     OR v_role <> 'driver'
     OR v_verified IS NOT TRUE
     OR v_online IS NOT TRUE THEN
    RAISE EXCEPTION 'حساب السائق غير مؤهل أو غير متصل';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.rides r
    WHERE r.driver_id = v_uid
      AND r.status IN ('accepted', 'arrived', 'in_progress')
  ) THEN
    RAISE EXCEPTION 'لديك رحلة نشطة بالفعل';
  END IF;

  SELECT r.status
  INTO v_status
  FROM public.rides r
  WHERE r.id = p_ride_id
  FOR UPDATE;

  IF NOT FOUND OR v_status <> 'searching' THEN
    RETURN FALSE;
  END IF;

  UPDATE public.rides
  SET driver_id = v_uid,
      status = 'accepted',
      driver_lat = NULL,
      driver_lng = NULL
  WHERE id = p_ride_id
    AND status = 'searching'
    AND driver_id IS NULL;

  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  -- There is deliberately no fare, wallet debit, or commission.
  RETURN TRUE;
END;
$$;

-- ------------------------------------------------------------
-- 9. Driver-only status transitions
-- accepted -> arrived -> in_progress -> completed
-- Admins cannot cancel, modify, or force-complete rides.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.set_ride_status_secure(
  p_ride_id UUID,
  p_next_status TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_current TEXT;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  SELECT r.status
  INTO v_current
  FROM public.rides r
  WHERE r.id = p_ride_id
    AND r.driver_id = v_uid
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'الرحلة غير موجودة أو لا تخص هذا السائق';
  END IF;

  IF NOT (
    (v_current = 'accepted' AND p_next_status = 'arrived')
    OR (v_current = 'arrived' AND p_next_status = 'in_progress')
    OR (v_current = 'in_progress' AND p_next_status = 'completed')
  ) THEN
    RAISE EXCEPTION 'تغيير حالة الرحلة غير مسموح';
  END IF;

  UPDATE public.rides
  SET status = p_next_status
  WHERE id = p_ride_id;

  RETURN TRUE;
END;
$$;

-- ------------------------------------------------------------
-- 10. Rider can cancel only an unassigned searching request.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.cancel_searching_ride_secure(p_ride_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  UPDATE public.rides
  SET status = 'cancelled'
  WHERE id = p_ride_id
    AND rider_id = auth.uid()
    AND status = 'searching'
    AND driver_id IS NULL;

  RETURN FOUND;
END;
$$;

-- ------------------------------------------------------------
-- 11. Driver location: only assigned driver, only active ride.
-- Coordinates are stored on the ride so RLS protects their access.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.update_driver_location_secure(
  p_ride_id UUID,
  p_lat DOUBLE PRECISION,
  p_lng DOUBLE PRECISION
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  IF p_lat IS NULL OR p_lat NOT BETWEEN -90 AND 90
     OR p_lng IS NULL OR p_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'إحداثيات الموقع غير صحيحة';
  END IF;

  UPDATE public.rides
  SET driver_lat = p_lat,
      driver_lng = p_lng
  WHERE id = p_ride_id
    AND driver_id = auth.uid()
    AND status IN ('accepted', 'arrived', 'in_progress');

  RETURN FOUND;
END;
$$;

-- ------------------------------------------------------------
-- 12. Driver online/offline
-- No wallet or minimum-balance requirement is applied.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.set_driver_online_secure(p_is_online BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_role TEXT;
  v_verified BOOLEAN;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  SELECT p.role, p.is_verified
  INTO v_role, v_verified
  FROM public.profiles p
  WHERE p.id = auth.uid()
  FOR UPDATE;

  IF NOT FOUND OR v_role <> 'driver' THEN
    RAISE EXCEPTION 'هذه العملية مخصصة للسائقين';
  END IF;

  IF p_is_online IS TRUE AND v_verified IS NOT TRUE THEN
    RAISE EXCEPTION 'يجب اعتماد حساب السائق من الإدارة أولاً';
  END IF;

  IF p_is_online IS FALSE AND EXISTS (
    SELECT 1
    FROM public.rides r
    WHERE r.driver_id = auth.uid()
      AND r.status IN ('accepted', 'arrived', 'in_progress')
  ) THEN
    RAISE EXCEPTION 'لا يمكن قطع الاتصال أثناء وجود رحلة نشطة';
  END IF;

  UPDATE public.profiles
  SET is_online = p_is_online
  WHERE id = auth.uid();

  RETURN TRUE;
END;
$$;

-- ------------------------------------------------------------
-- 13. Rider rating: one rating after completion.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.rate_completed_ride_secure(
  p_ride_id UUID,
  p_rating SMALLINT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  IF p_rating IS NULL OR p_rating NOT BETWEEN 1 AND 5 THEN
    RAISE EXCEPTION 'التقييم يجب أن يكون بين 1 و5';
  END IF;

  UPDATE public.rides
  SET rating = p_rating
  WHERE id = p_ride_id
    AND rider_id = auth.uid()
    AND status = 'completed'
    AND rating IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'لا يمكن تقييم الرحلة أو سبق تقييمها';
  END IF;

  RETURN TRUE;
END;
$$;

-- ------------------------------------------------------------
-- 14. Admin verification only.
-- This function cannot update or cancel rides.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.admin_set_driver_verification_secure(
  p_driver_id UUID,
  p_verified BOOLEAN
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() THEN
    RAISE EXCEPTION 'غير مصرح لك بتنفيذ هذه العملية';
  END IF;

  PERFORM 1
  FROM public.profiles p
  WHERE p.id = p_driver_id
    AND p.role = 'driver'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'السائق غير موجود';
  END IF;

  IF p_verified IS FALSE AND EXISTS (
    SELECT 1
    FROM public.rides r
    WHERE r.driver_id = p_driver_id
      AND r.status IN ('accepted', 'arrived', 'in_progress')
  ) THEN
    RAISE EXCEPTION 'لا يمكن إلغاء اعتماد سائق لديه رحلة نشطة';
  END IF;

  UPDATE public.profiles
  SET is_verified = p_verified,
      is_online = CASE WHEN p_verified THEN is_online ELSE FALSE END
  WHERE id = p_driver_id;

  RETURN TRUE;
END;
$$;


-- ------------------------------------------------------------
-- 14a. Safe admin listing: never returns phone numbers.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_list_pending_drivers_secure()
RETURNS TABLE (
  id UUID,
  full_name TEXT,
  is_verified BOOLEAN,
  is_online BOOLEAN,
  car_model TEXT,
  plate_number TEXT,
  created_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() THEN
    RAISE EXCEPTION 'غير مصرح لك بعرض بيانات السائقين';
  END IF;

  RETURN QUERY
  SELECT p.id, p.full_name, p.is_verified, p.is_online,
         p.car_model, p.plate_number, p.created_at
  FROM public.profiles p
  WHERE p.role = 'driver' AND p.is_verified IS FALSE
  ORDER BY p.created_at DESC;
END;
$$;

-- ------------------------------------------------------------
-- 14b. Contact phone is available only to ride participants
-- while the ride is accepted, arrived, or in progress.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_ride_contact_phone_secure(p_ride_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_rider UUID;
  v_driver UUID;
  v_status TEXT;
  v_phone TEXT;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  SELECT r.rider_id, r.driver_id, r.status
  INTO v_rider, v_driver, v_status
  FROM public.rides r
  WHERE r.id = p_ride_id
  FOR UPDATE;

  IF NOT FOUND OR v_status NOT IN ('accepted', 'arrived', 'in_progress') THEN
    RAISE EXCEPTION 'بيانات الاتصال غير متاحة لهذه الرحلة';
  END IF;

  IF v_uid = v_rider AND v_driver IS NOT NULL THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id = v_driver;
  ELSIF v_uid = v_driver THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id = v_rider;
  ELSE
    RAISE EXCEPTION 'غير مصرح لك بالوصول إلى رقم الهاتف';
  END IF;

  IF v_phone IS NULL OR btrim(v_phone) = '' THEN
    RAISE EXCEPTION 'رقم الهاتف غير متوفر';
  END IF;

  RETURN v_phone;
END;
$$;

-- ------------------------------------------------------------
-- 15. Function execution permissions
-- ------------------------------------------------------------

REVOKE ALL ON FUNCTION public.is_admin_user() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_eligible_driver() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.create_ride_secure(TEXT, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION, DOUBLE PRECISION) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.accept_ride_secure(UUID) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.set_ride_status_secure(UUID, TEXT) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.cancel_searching_ride_secure(UUID) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.update_driver_location_secure(UUID, DOUBLE PRECISION, DOUBLE PRECISION) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.set_driver_online_secure(BOOLEAN) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.rate_completed_ride_secure(UUID, SMALLINT) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_set_driver_verification_secure(UUID, BOOLEAN) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_list_pending_drivers_secure() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.get_ride_contact_phone_secure(UUID) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.handle_new_auth_user() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.is_admin_user() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_eligible_driver() TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_ride_secure(TEXT, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION, DOUBLE PRECISION) TO authenticated;
GRANT EXECUTE ON FUNCTION public.accept_ride_secure(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_ride_status_secure(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_searching_ride_secure(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_driver_location_secure(UUID, DOUBLE PRECISION, DOUBLE PRECISION) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_driver_online_secure(BOOLEAN) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rate_completed_ride_secure(UUID, SMALLINT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_set_driver_verification_secure(UUID, BOOLEAN) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_pending_drivers_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_ride_contact_phone_secure(UUID) TO authenticated;

-- ------------------------------------------------------------
-- 16. Realtime publication (idempotent)
-- ------------------------------------------------------------

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public' AND tablename = 'rides'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE public.rides;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public' AND tablename = 'profiles'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
    END IF;
  END IF;
END;
$$;

COMMIT;

-- ============================================================
-- FIRST ADMIN BOOTSTRAP - manual, once only, after signup
-- 1) Register your own account through the app.
-- 2) Find that user's UUID in Supabase Authentication > Users.
-- 3) Run the statement below in SQL Editor, replacing the UUID.
-- This is an owner-level setup action; never expose service_role.
--
-- UPDATE public.profiles
-- SET role = 'admin', is_verified = TRUE, is_online = FALSE
-- WHERE id = 'PASTE-YOUR-AUTH-USER-UUID-HERE'
--   AND role = 'rider';
--
-- Verify exactly one row was updated. Do not make admin creation
-- available from the public app.
-- ============================================================
