-- TAXI OUARGLA LITE V3.9
-- Existing-database migration: enforce one active ride per rider AND driver.
-- Review and resolve reported duplicates manually before rerunning.
-- Active rider states: searching, accepted, arrived, in_progress.
-- Active driver states: accepted, arrived, in_progress.

BEGIN;

DO $$
DECLARE
  v_rider_duplicates TEXT;
  v_driver_duplicates TEXT;
BEGIN
  SELECT string_agg(format('%s (%s)', rider_id, active_count), ', ')
    INTO v_rider_duplicates
  FROM (
    SELECT rider_id, count(*) AS active_count
    FROM public.rides
    WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress')
    GROUP BY rider_id
    HAVING count(*) > 1
    ORDER BY rider_id
    LIMIT 20
  ) d;

  SELECT string_agg(format('%s (%s)', driver_id, active_count), ', ')
    INTO v_driver_duplicates
  FROM (
    SELECT driver_id, count(*) AS active_count
    FROM public.rides
    WHERE driver_id IS NOT NULL
      AND status IN ('accepted', 'arrived', 'in_progress')
    GROUP BY driver_id
    HAVING count(*) > 1
    ORDER BY driver_id
    LIMIT 20
  ) d;

  IF v_rider_duplicates IS NOT NULL OR v_driver_duplicates IS NOT NULL THEN
    RAISE EXCEPTION
      'Active ride duplicates found. Riders: %. Drivers: %.',
      COALESCE(v_rider_duplicates, 'none'),
      COALESCE(v_driver_duplicates, 'none')
      USING HINT = 'Review the listed rides manually. Do not delete or cancel records automatically, then rerun this migration.';
  END IF;
END;
$$;

CREATE UNIQUE INDEX IF NOT EXISTS one_active_ride_per_rider
  ON public.rides (rider_id)
  WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress');

CREATE UNIQUE INDEX IF NOT EXISTS one_active_ride_per_driver
  ON public.rides (driver_id)
  WHERE driver_id IS NOT NULL
    AND status IN ('accepted', 'arrived', 'in_progress');

COMMIT;
