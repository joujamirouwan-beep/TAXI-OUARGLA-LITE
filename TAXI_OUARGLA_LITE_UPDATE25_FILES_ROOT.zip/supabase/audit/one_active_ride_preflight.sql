-- READ ONLY. Run these queries before the rider-index migration.

-- 1) Active-ride duplicates by rider. Zero rows means no duplicates found.
SELECT rider_id, COUNT(*) AS active_count,
       ARRAY_AGG(id ORDER BY created_at) AS ride_ids
FROM public.rides
WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress')
GROUP BY rider_id
HAVING COUNT(*) > 1
ORDER BY active_count DESC, rider_id;

-- 2) Active-ride duplicates by driver. Zero rows means no duplicates found.
SELECT driver_id, COUNT(*) AS active_count,
       ARRAY_AGG(id ORDER BY created_at) AS ride_ids
FROM public.rides
WHERE driver_id IS NOT NULL
  AND status IN ('accepted', 'arrived', 'in_progress')
GROUP BY driver_id
HAVING COUNT(*) > 1
ORDER BY active_count DESC, driver_id;

-- 3) Inspect all rides indexes and their exact definitions.
SELECT indexname, indexdef
FROM pg_catalog.pg_indexes
WHERE schemaname = 'public' AND tablename = 'rides'
ORDER BY indexname;

-- 4) Confirm the new index after a reviewed migration.
SELECT indexname, indexdef
FROM pg_catalog.pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'rides'
  AND indexname = 'rides_one_active_per_rider_v1';
