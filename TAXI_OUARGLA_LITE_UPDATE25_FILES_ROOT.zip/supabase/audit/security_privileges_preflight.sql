-- Run after applying the approved schema/migrations.
-- Every returned boolean must match the expected value shown in comments.

SELECT
  has_column_privilege('authenticated', 'public.profiles', 'phone', 'SELECT')
    AS authenticated_can_read_profile_phone, -- expected FALSE
  has_table_privilege('authenticated', 'public.rides', 'INSERT')
    AS authenticated_can_insert_rides_directly, -- expected FALSE
  has_table_privilege('authenticated', 'public.rides', 'UPDATE')
    AS authenticated_can_update_rides_directly, -- expected FALSE
  has_function_privilege(
    'authenticated',
    'public.create_ride_secure(text,double precision,double precision,text,double precision,double precision)',
    'EXECUTE'
  ) AS authenticated_can_create_via_rpc, -- expected TRUE
  has_function_privilege(
    'authenticated', 'public.get_ride_contact_phone_secure(uuid)', 'EXECUTE'
  ) AS authenticated_can_call_contact_rpc; -- expected TRUE

-- Confirm only the six approved ride states exist in the check constraint.
SELECT conname, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conrelid = 'public.rides'::regclass
  AND contype = 'c'
  AND pg_get_constraintdef(oid) ILIKE '%status%';

-- Confirm the unique active-ride indexes are present.
SELECT indexname, indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'rides'
  AND indexname IN ('one_active_ride_per_rider', 'one_active_ride_per_driver')
ORDER BY indexname;
