-- Run on a staging database before applying migration 007.
-- Read-only checks: this script does not modify schema or data.
DO $check$
DECLARE
  v_missing text[] := ARRAY[]::text[];
BEGIN
  IF to_regclass('public.profiles') IS NULL THEN
    v_missing := array_append(v_missing, 'public.profiles');
  END IF;
  IF to_regclass('public.rides') IS NULL THEN
    v_missing := array_append(v_missing, 'public.rides');
  END IF;
  IF to_regprocedure('public.is_admin_user()') IS NULL THEN
    RAISE NOTICE 'Existing admin helper is absent; verify migration order before proceeding.';
  END IF;

  IF to_regclass('public.profiles') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='id' AND data_type='uuid') THEN
      v_missing := array_append(v_missing, 'profiles.id UUID');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='role') THEN
      v_missing := array_append(v_missing, 'profiles.role');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='is_verified') THEN
      v_missing := array_append(v_missing, 'profiles.is_verified');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='is_online') THEN
      v_missing := array_append(v_missing, 'profiles.is_online');
    END IF;
  END IF;

  IF to_regclass('public.rides') IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='id' AND data_type='uuid') THEN
      v_missing := array_append(v_missing, 'rides.id UUID');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='rider_id' AND data_type='uuid') THEN
      v_missing := array_append(v_missing, 'rides.rider_id UUID');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='driver_id' AND data_type='uuid') THEN
      v_missing := array_append(v_missing, 'rides.driver_id UUID');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='status' AND data_type='text') THEN
      v_missing := array_append(v_missing, 'rides.status TEXT');
    END IF;
  END IF;

  IF cardinality(v_missing) > 0 THEN
    RAISE EXCEPTION 'Notification migration preflight failed. Missing/incompatible: %', array_to_string(v_missing, ', ');
  END IF;
  RAISE NOTICE 'Notification migration preflight passed for required profiles/rides columns.';
END
$check$;

-- After migration 007, run these read-only privilege/RLS checks:
SELECT
  c.relrowsecurity AS rls_enabled,
  has_table_privilege('authenticated', 'public.user_notifications', 'SELECT') AS authenticated_can_select,
  has_column_privilege('authenticated', 'public.user_notifications', 'read_at', 'UPDATE') AS authenticated_can_update_read_at,
  has_column_privilege('authenticated', 'public.user_notifications', 'body', 'UPDATE') AS authenticated_cannot_update_body
FROM pg_class c
WHERE c.oid = to_regclass('public.user_notifications');
