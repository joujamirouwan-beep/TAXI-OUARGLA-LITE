-- TAXI OUARGLA LITE: core RPC and privilege postflight audit.
-- Run only AFTER the approved migrations on STAGING. Read-only; raises on failure.
DO $core_security_postflight$
DECLARE
  v_sig text;
  v_oid oid;
  v_cfg text[];
  v_expected text[] := ARRAY[
    'public.create_ride_secure(text,double precision,double precision,text,double precision,double precision)',
    'public.accept_ride_secure(uuid)',
    'public.set_ride_status_secure(uuid,text)',
    'public.cancel_searching_ride_secure(uuid)',
    'public.update_driver_location_secure(uuid,double precision,double precision)',
    'public.set_driver_online_secure(boolean)',
    'public.rate_completed_ride_secure(uuid,smallint)',
    'public.get_ride_contact_phone_secure(uuid)',
    'public.list_available_rides_secure()',
    'public.list_my_rides_secure()',
    'public.admin_list_rides_secure()',
    'public.admin_list_pending_drivers_secure()',
    'public.admin_set_driver_verification_secure(uuid,boolean)'
  ];
BEGIN
  IF to_regclass('public.rides') IS NULL OR to_regclass('public.profiles') IS NULL THEN
    RAISE EXCEPTION 'Core security postflight failed: rides/profiles table missing';
  END IF;

  FOREACH v_sig IN ARRAY v_expected LOOP
    v_oid := to_regprocedure(v_sig);
    IF v_oid IS NULL THEN
      RAISE EXCEPTION 'Core security postflight failed: missing RPC signature %', v_sig;
    END IF;

    SELECT p.proconfig INTO v_cfg FROM pg_proc p WHERE p.oid = v_oid;
    IF NOT (SELECT p.prosecdef FROM pg_proc p WHERE p.oid = v_oid) THEN
      RAISE EXCEPTION 'Core security postflight failed: RPC is not SECURITY DEFINER: %', v_sig;
    END IF;
    IF NOT coalesce(v_cfg @> ARRAY['search_path=""'], false)
       OR NOT coalesce(v_cfg @> ARRAY['row_security=off'], false) THEN
      RAISE EXCEPTION 'Core security postflight failed: unsafe function config: %', v_sig;
    END IF;
    IF has_function_privilege('anon', v_oid, 'EXECUTE')
       OR NOT has_function_privilege('authenticated', v_oid, 'EXECUTE') THEN
      RAISE EXCEPTION 'Core security postflight failed: incorrect client EXECUTE grants: %', v_sig;
    END IF;
  END LOOP;

  IF has_any_column_privilege('authenticated', 'public.rides', 'INSERT')
     OR has_any_column_privilege('authenticated', 'public.rides', 'UPDATE')
     OR has_any_column_privilege('authenticated', 'public.rides', 'DELETE') THEN
    RAISE EXCEPTION 'Core security postflight failed: authenticated has direct rides DML privileges';
  END IF;

  IF has_column_privilege('authenticated', 'public.profiles', 'phone', 'SELECT') THEN
    RAISE EXCEPTION 'Core security postflight failed: authenticated can read profiles.phone';
  END IF;

  IF to_regclass('public.uq_rides_one_active_trip_per_rider') IS NULL
     OR to_regclass('public.uq_rides_one_active_trip_per_driver') IS NULL THEN
    RAISE EXCEPTION 'Core security postflight failed: active-ride unique indexes are missing';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'public.rides'::regclass
      AND conname = 'rides_status_v31_check'
      AND contype = 'c' AND convalidated
  ) THEN
    RAISE EXCEPTION 'Core security postflight failed: validated six-state ride constraint is missing';
  END IF;

  RAISE NOTICE 'Core security postflight passed: RPC signatures/config/grants, no direct rides DML, phone protection, active-ride indexes and validated status constraint.';
END
$core_security_postflight$;

-- Readable evidence for the deployment record.
SELECT
  to_regprocedure('public.create_ride_secure(text,double precision,double precision,text,double precision,double precision)') IS NOT NULL AS create_ride_rpc_present,
  to_regprocedure('public.accept_ride_secure(uuid)') IS NOT NULL AS accept_ride_rpc_present,
  has_any_column_privilege('authenticated', 'public.rides', 'INSERT') AS authenticated_has_direct_ride_insert,
  has_any_column_privilege('authenticated', 'public.rides', 'UPDATE') AS authenticated_has_direct_ride_update,
  has_column_privilege('authenticated', 'public.profiles', 'phone', 'SELECT') AS authenticated_can_read_phone,
  to_regclass('public.uq_rides_one_active_trip_per_rider') IS NOT NULL AS rider_active_unique_index_present,
  to_regclass('public.uq_rides_one_active_trip_per_driver') IS NOT NULL AS driver_active_unique_index_present;
