-- TAXI OUARGLA LITE: notification migration 007 postflight audit.
-- Run AFTER migration 007 on STAGING first. Read-only; raises if security setup is incomplete.
DO $notification_postflight$
DECLARE
  v_policy_count integer;
  v_trigger_count integer;
  v_function_oid oid;
  v_function_config text[];
BEGIN
  IF to_regclass('public.user_notifications') IS NULL THEN
    RAISE EXCEPTION 'Notification postflight failed: user_notifications table is missing';
  END IF;

  IF NOT (SELECT c.relrowsecurity
          FROM pg_class c
          WHERE c.oid = 'public.user_notifications'::regclass) THEN
    RAISE EXCEPTION 'Notification postflight failed: RLS is disabled';
  END IF;

  SELECT count(*) INTO v_policy_count
  FROM pg_policies
  WHERE schemaname = 'public'
    AND tablename = 'user_notifications'
    AND policyname IN ('user_notifications_read_own', 'user_notifications_mark_own_read');
  IF v_policy_count <> 2 OR
     (SELECT count(*) FROM pg_policies
      WHERE schemaname = 'public' AND tablename = 'user_notifications') <> 2 THEN
    RAISE EXCEPTION 'Notification postflight failed: unexpected policy inventory';
  END IF;

  IF NOT has_table_privilege('authenticated', 'public.user_notifications', 'SELECT')
     OR has_table_privilege('anon', 'public.user_notifications', 'SELECT')
     OR has_table_privilege('authenticated', 'public.user_notifications', 'INSERT')
     OR has_table_privilege('authenticated', 'public.user_notifications', 'DELETE') THEN
    RAISE EXCEPTION 'Notification postflight failed: table grants are too broad or incomplete';
  END IF;

  IF NOT has_column_privilege('authenticated', 'public.user_notifications', 'read_at', 'UPDATE')
     OR has_column_privilege('authenticated', 'public.user_notifications', 'title', 'UPDATE')
     OR has_column_privilege('authenticated', 'public.user_notifications', 'body', 'UPDATE')
     OR has_column_privilege('authenticated', 'public.user_notifications', 'user_id', 'UPDATE') THEN
    RAISE EXCEPTION 'Notification postflight failed: column update grants are incorrect';
  END IF;

  SELECT p.oid, p.proconfig INTO v_function_oid, v_function_config
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'create_ride_notifications_v1'
    AND pg_get_function_identity_arguments(p.oid) = '';

  IF v_function_oid IS NULL THEN
    RAISE EXCEPTION 'Notification postflight failed: trigger function is missing';
  END IF;

  IF NOT (SELECT p.prosecdef FROM pg_proc p WHERE p.oid = v_function_oid) THEN
    RAISE EXCEPTION 'Notification postflight failed: trigger function must be SECURITY DEFINER';
  END IF;

  IF NOT coalesce(v_function_config @> ARRAY['search_path=""'], false)
     OR NOT coalesce(v_function_config @> ARRAY['row_security=off'], false) THEN
    RAISE EXCEPTION 'Notification postflight failed: function search_path/row_security config is unsafe';
  END IF;

  IF has_function_privilege('anon', v_function_oid, 'EXECUTE')
     OR has_function_privilege('authenticated', v_function_oid, 'EXECUTE') THEN
    RAISE EXCEPTION 'Notification postflight failed: trigger function is directly executable by clients';
  END IF;

  SELECT count(*) INTO v_trigger_count
  FROM pg_trigger t
  WHERE t.tgrelid = 'public.rides'::regclass
    AND t.tgname = 'rides_create_notifications_v1'
    AND NOT t.tgisinternal
    AND t.tgenabled = 'O';
  IF v_trigger_count <> 1 THEN
    RAISE EXCEPTION 'Notification postflight failed: expected enabled rides notification trigger is missing';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE schemaname = 'public' AND tablename = 'user_notifications'
      AND indexname = 'user_notifications_user_created_idx'
  ) THEN
    RAISE EXCEPTION 'Notification postflight failed: user/created index is missing';
  END IF;

  RAISE NOTICE 'Notification postflight passed: RLS, owner policies, restricted grants, secure trigger function and enabled trigger verified.';
END
$notification_postflight$;

-- Human-readable summary for the deployment record.
SELECT
  (SELECT relrowsecurity FROM pg_class WHERE oid = 'public.user_notifications'::regclass) AS rls_enabled,
  has_table_privilege('authenticated', 'public.user_notifications', 'SELECT') AS authenticated_can_read,
  has_column_privilege('authenticated', 'public.user_notifications', 'read_at', 'UPDATE') AS authenticated_can_mark_read,
  has_column_privilege('authenticated', 'public.user_notifications', 'body', 'UPDATE') AS authenticated_cannot_edit_body,
  EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgrelid = 'public.rides'::regclass
      AND tgname = 'rides_create_notifications_v1'
      AND NOT tgisinternal AND tgenabled = 'O'
  ) AS rides_notification_trigger_enabled;
