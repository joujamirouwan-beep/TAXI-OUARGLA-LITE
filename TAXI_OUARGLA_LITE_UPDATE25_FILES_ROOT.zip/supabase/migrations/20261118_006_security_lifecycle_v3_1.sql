-- TAXI OUARGLA LITE V3.10.1
-- Existing-project hardening migration aligned to SOURCE_UPDATE_05.
-- IMPORTANT: This archive's canonical schema uses rides.status TEXT + CHECK,
-- and stores driver coordinates on rides.driver_lat/driver_lng. It does NOT
-- define ride_status_enum or public.driver_locations. This migration fails
-- closed if the live schema differs. Test on a staging database first.

BEGIN;
SET LOCAL lock_timeout = '10s';
SET LOCAL statement_timeout = '120s';

-- ---------------------------------------------------------------------
-- 00. Preflight: refuse to guess at a different live schema.
-- ---------------------------------------------------------------------
DO $preflight$
DECLARE v_type text;
BEGIN
  IF to_regclass('public.profiles') IS NULL OR to_regclass('public.rides') IS NULL THEN
    RAISE EXCEPTION 'V3.1 preflight failed: public.profiles and public.rides are required';
  END IF;

  IF to_regclass('public.driver_locations') IS NOT NULL OR to_regclass('public.ride_ratings') IS NOT NULL THEN
    RAISE EXCEPTION 'V3.1 source mismatch: separate driver_locations/ride_ratings tables exist but are not part of SOURCE_UPDATE_05 contract; audit them before proceeding';
  END IF;

  -- The preceding V2/V2.1 installation and migration 005 must have installed
  -- the administrator helper. Policies below depend on this exact signature.
  IF to_regprocedure('public.is_admin_user()') IS NULL THEN
    RAISE EXCEPTION 'V3.1 preflight failed: public.is_admin_user() is missing';
  END IF;

  -- Refuse stale/experimental overloads instead of leaving an alternate RPC
  -- callable beside the contract used by Flutter/PostgREST.
  IF EXISTS (
    SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
    WHERE n.nspname='public' AND p.proname IN (
      'create_ride_secure','accept_ride_secure','set_ride_status_secure',
      'cancel_searching_ride_secure','update_driver_location_secure',
      'set_driver_online_secure','rate_completed_ride_secure',
      'get_ride_contact_phone_secure','admin_list_pending_drivers_secure',
      'admin_set_driver_verification_secure','list_available_rides_secure',
      'list_my_rides_secure','admin_list_rides_secure'
    ) AND NOT (
      (p.proname='create_ride_secure' AND oidvectortypes(p.proargtypes)='text, double precision, double precision, text, double precision, double precision') OR
      (p.proname='accept_ride_secure' AND oidvectortypes(p.proargtypes)='uuid') OR
      (p.proname='set_ride_status_secure' AND oidvectortypes(p.proargtypes)='uuid, text') OR
      (p.proname='cancel_searching_ride_secure' AND oidvectortypes(p.proargtypes)='uuid') OR
      (p.proname='update_driver_location_secure' AND oidvectortypes(p.proargtypes)='uuid, double precision, double precision') OR
      (p.proname='set_driver_online_secure' AND oidvectortypes(p.proargtypes)='boolean') OR
      (p.proname='rate_completed_ride_secure' AND oidvectortypes(p.proargtypes)='uuid, smallint') OR
      (p.proname='get_ride_contact_phone_secure' AND oidvectortypes(p.proargtypes)='uuid') OR
      (p.proname='admin_list_pending_drivers_secure' AND oidvectortypes(p.proargtypes)='') OR
      (p.proname='admin_set_driver_verification_secure' AND oidvectortypes(p.proargtypes)='uuid, boolean') OR
      (p.proname='list_available_rides_secure' AND oidvectortypes(p.proargtypes)='') OR
      (p.proname='list_my_rides_secure' AND oidvectortypes(p.proargtypes)='') OR
      (p.proname='admin_list_rides_secure' AND oidvectortypes(p.proargtypes)='')
    )
  ) THEN
    RAISE EXCEPTION 'V3.1 preflight failed: unexpected RPC overload/signature exists; reconcile Flutter and database contracts first';
  END IF;

  SELECT format_type(a.atttypid, a.atttypmod) INTO v_type
  FROM pg_attribute a
  WHERE a.attrelid = 'public.rides'::regclass AND a.attname = 'status' AND NOT a.attisdropped;
  IF v_type IS DISTINCT FROM 'text' THEN
    RAISE EXCEPTION 'V3.1 expects public.rides.status TEXT (found %). Stop and reconcile schema/contracts.', v_type;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='rider_id' AND data_type='uuid')
     OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='driver_id' AND data_type='uuid')
     OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='driver_lat')
     OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='rides' AND column_name='driver_lng')
     OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='profiles' AND column_name='phone') THEN
    RAISE EXCEPTION 'V3.1 preflight failed: expected columns are missing';
  END IF;

  IF EXISTS (SELECT 1 FROM public.rides WHERE status IS NULL OR status NOT IN
    ('searching','accepted','arrived','in_progress','completed','cancelled')) THEN
    RAISE EXCEPTION 'V3.1 preflight failed: rides contains NULL or unsupported status values';
  END IF;

  IF EXISTS (
    SELECT rider_id FROM public.rides
    WHERE status IN ('searching','accepted','arrived','in_progress')
    GROUP BY rider_id HAVING count(*) > 1
  ) THEN RAISE EXCEPTION 'V3.1 preflight failed: duplicate active rides for a rider'; END IF;

  IF EXISTS (
    SELECT driver_id FROM public.rides
    WHERE driver_id IS NOT NULL AND status IN ('accepted','arrived','in_progress')
    GROUP BY driver_id HAVING count(*) > 1
  ) THEN RAISE EXCEPTION 'V3.1 preflight failed: duplicate active rides for a driver'; END IF;
END
$preflight$;

-- Ensure the exact six-state domain even if an older CHECK was incomplete.
DO $constraints$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='public.rides'::regclass AND conname='rides_status_v31_check') THEN
    ALTER TABLE public.rides ADD CONSTRAINT rides_status_v31_check
      CHECK (status IN ('searching','accepted','arrived','in_progress','completed','cancelled')) NOT VALID;
  END IF;
  ALTER TABLE public.rides VALIDATE CONSTRAINT rides_status_v31_check;
  ALTER TABLE public.rides ALTER COLUMN status SET NOT NULL;
END
$constraints$;

-- ---------------------------------------------------------------------
-- 01. Database concurrency backstops.
-- ---------------------------------------------------------------------
CREATE UNIQUE INDEX IF NOT EXISTS uq_rides_one_active_trip_per_rider
  ON public.rides (rider_id)
  WHERE status IN ('searching','accepted','arrived','in_progress');

CREATE UNIQUE INDEX IF NOT EXISTS uq_rides_one_active_trip_per_driver
  ON public.rides (driver_id)
  WHERE driver_id IS NOT NULL AND status IN ('accepted','arrived','in_progress');

-- ---------------------------------------------------------------------
-- 02. RLS: remove every old rides policy (not just known policy names),
-- then expose only rows belonging to the caller or administrators.
-- Available searching rides are exposed only by a guarded RPC.
-- ---------------------------------------------------------------------
ALTER TABLE public.rides ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DO $drop_ride_policies$
DECLARE r record;
BEGIN
  FOR r IN SELECT policyname FROM pg_policies WHERE schemaname='public' AND tablename='rides'
  LOOP EXECUTE format('DROP POLICY %I ON public.rides', r.policyname); END LOOP;
END
$drop_ride_policies$;

CREATE POLICY rides_select_participants_admin_v31
ON public.rides FOR SELECT TO authenticated
USING (rider_id = auth.uid() OR driver_id = auth.uid() OR public.is_admin_user());

-- Profiles policies are rebuilt to prevent stale permissive policies from
-- widening visibility. Column grants below still exclude phone.
DO $drop_profile_policies$
DECLARE r record;
BEGIN
  FOR r IN SELECT policyname FROM pg_policies WHERE schemaname='public' AND tablename='profiles'
  LOOP EXECUTE format('DROP POLICY %I ON public.profiles', r.policyname); END LOOP;
END
$drop_profile_policies$;

CREATE POLICY profiles_select_self_related_admin_v31
ON public.profiles FOR SELECT TO authenticated
USING (
  id = auth.uid()
  OR public.is_admin_user()
  OR EXISTS (
    SELECT 1 FROM public.rides r
    WHERE ((r.rider_id = auth.uid() AND r.driver_id = profiles.id)
        OR (r.driver_id = auth.uid() AND r.rider_id = profiles.id))
      AND r.status IN ('accepted','arrived','in_progress','completed')
  )
);

CREATE POLICY profiles_update_safe_self_v31
ON public.profiles FOR UPDATE TO authenticated
USING (id = auth.uid() AND role IN ('rider','driver'))
WITH CHECK (id = auth.uid() AND role IN ('rider','driver'));

-- ---------------------------------------------------------------------
-- 03. Least-privilege table/column grants.
-- ---------------------------------------------------------------------
REVOKE ALL ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
DO $revoke_profile_columns$
DECLARE c record;
BEGIN
  FOR c IN SELECT attname FROM pg_attribute WHERE attrelid='public.profiles'::regclass AND attnum > 0 AND NOT attisdropped
  LOOP EXECUTE format('REVOKE ALL (%I) ON TABLE public.profiles FROM PUBLIC, anon, authenticated', c.attname); END LOOP;
END
$revoke_profile_columns$;
REVOKE SELECT (phone) ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
GRANT SELECT (id, full_name, role, is_verified, is_online, car_model, plate_number, created_at, updated_at)
  ON TABLE public.profiles TO authenticated;
GRANT UPDATE (full_name, car_model, plate_number) ON TABLE public.profiles TO authenticated;

REVOKE ALL ON TABLE public.rides FROM PUBLIC, anon, authenticated;
DO $revoke_ride_columns$
DECLARE c record;
BEGIN
  FOR c IN SELECT attname FROM pg_attribute WHERE attrelid='public.rides'::regclass AND attnum > 0 AND NOT attisdropped
  LOOP EXECUTE format('REVOKE ALL (%I) ON TABLE public.rides FROM PUBLIC, anon, authenticated', c.attname); END LOOP;
END
$revoke_ride_columns$;
GRANT SELECT ON TABLE public.rides TO authenticated;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON TABLE public.rides FROM PUBLIC, anon, authenticated;

-- ---------------------------------------------------------------------
-- 04. Harden helper functions.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$ SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin') $$;

CREATE OR REPLACE FUNCTION public.is_eligible_driver()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$ SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role='driver' AND p.is_verified IS TRUE AND p.is_online IS TRUE) $$;

-- ---------------------------------------------------------------------
-- 05. Secure read RPCs. No direct discovery of searching rides.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.list_available_rides_secure()
RETURNS TABLE (
  id uuid, rider_id uuid, driver_id uuid, pickup_address text,
  pickup_lat double precision, pickup_lng double precision,
  dropoff_address text, dropoff_lat double precision, dropoff_lng double precision,
  status text, driver_lat double precision, driver_lng double precision,
  rating smallint, created_at timestamptz, updated_at timestamptz
)
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_eligible_driver() THEN
    RAISE EXCEPTION 'السائق غير مؤهل لعرض الطلبات';
  END IF;
  RETURN QUERY
  SELECT r.id,r.rider_id,r.driver_id,r.pickup_address,r.pickup_lat,r.pickup_lng,
         r.dropoff_address,r.dropoff_lat,r.dropoff_lng,r.status,r.driver_lat,r.driver_lng,
         r.rating,r.created_at,r.updated_at
  FROM public.rides r WHERE r.status='searching' AND r.driver_id IS NULL
  ORDER BY r.created_at DESC LIMIT 100;
END;
$$;

CREATE OR REPLACE FUNCTION public.list_my_rides_secure()
RETURNS SETOF public.rides
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'يجب تسجيل الدخول أولاً'; END IF;
  RETURN QUERY SELECT r.* FROM public.rides r
    WHERE r.rider_id=auth.uid() OR r.driver_id=auth.uid()
    ORDER BY r.created_at DESC LIMIT 200;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_list_rides_secure()
RETURNS SETOF public.rides
LANGUAGE plpgsql STABLE SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() THEN
    RAISE EXCEPTION 'غير مصرح لك بعرض الرحلات';
  END IF;
  RETURN QUERY SELECT r.* FROM public.rides r ORDER BY r.created_at DESC LIMIT 500;
END;
$$;

-- ---------------------------------------------------------------------
-- 06. Secure write lifecycle. Lock order whenever both rows are needed:
-- profiles first, then rides. No function below locks rides then profiles.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_ride_secure(
  p_pickup_address text, p_pickup_lat double precision, p_pickup_lng double precision,
  p_dropoff_address text, p_dropoff_lat double precision, p_dropoff_lng double precision
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid := auth.uid(); v_role text; v_ride public.rides%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'يجب تسجيل الدخول أولاً'; END IF;
  IF p_pickup_address IS NULL OR char_length(btrim(p_pickup_address)) NOT BETWEEN 2 AND 300
     OR p_dropoff_address IS NULL OR char_length(btrim(p_dropoff_address)) NOT BETWEEN 2 AND 300 THEN
    RAISE EXCEPTION 'يرجى إدخال عنوان صحيح للانطلاق والوجهة';
  END IF;
  IF p_pickup_lat IS NULL OR p_pickup_lat NOT BETWEEN -90 AND 90
     OR p_pickup_lng IS NULL OR p_pickup_lng NOT BETWEEN -180 AND 180
     OR p_dropoff_lat IS NULL OR p_dropoff_lat NOT BETWEEN -90 AND 90
     OR p_dropoff_lng IS NULL OR p_dropoff_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'إحداثيات الموقع غير صحيحة';
  END IF;
  SELECT p.role INTO v_role FROM public.profiles p WHERE p.id=v_uid FOR UPDATE;
  IF NOT FOUND OR v_role IS DISTINCT FROM 'rider' THEN RAISE EXCEPTION 'إنشاء الرحلات متاح للركاب فقط'; END IF;
  IF EXISTS (SELECT 1 FROM public.rides r WHERE r.rider_id=v_uid AND r.status IN ('searching','accepted','arrived','in_progress')) THEN
    RAISE EXCEPTION 'لديك طلب رحلة نشط بالفعل';
  END IF;
  INSERT INTO public.rides(rider_id,pickup_address,pickup_lat,pickup_lng,dropoff_address,dropoff_lat,dropoff_lng)
  VALUES(v_uid,btrim(p_pickup_address),p_pickup_lat,p_pickup_lng,btrim(p_dropoff_address),p_dropoff_lat,p_dropoff_lng)
  RETURNING * INTO v_ride;
  RETURN jsonb_build_object('id',v_ride.id,'status',v_ride.status,'created_at',v_ride.created_at);
END;
$$;

CREATE OR REPLACE FUNCTION public.accept_ride_secure(p_ride_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_role text; v_verified boolean; v_online boolean; v_status text;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL THEN RAISE EXCEPTION 'طلب غير صالح أو جلسة غير مسجلة'; END IF;
  SELECT p.role,p.is_verified,p.is_online INTO v_role,v_verified,v_online
    FROM public.profiles p WHERE p.id=v_uid FOR UPDATE;
  IF NOT FOUND OR v_role IS DISTINCT FROM 'driver' OR v_verified IS NOT TRUE OR v_online IS NOT TRUE THEN
    RAISE EXCEPTION 'حساب السائق غير مؤهل أو غير متصل';
  END IF;
  IF EXISTS(SELECT 1 FROM public.rides r WHERE r.driver_id=v_uid AND r.status IN ('accepted','arrived','in_progress')) THEN
    RAISE EXCEPTION 'لديك رحلة نشطة بالفعل';
  END IF;
  SELECT r.status INTO v_status FROM public.rides r WHERE r.id=p_ride_id FOR UPDATE;
  IF NOT FOUND OR v_status IS DISTINCT FROM 'searching' THEN RETURN FALSE; END IF;
  UPDATE public.rides SET driver_id=v_uid,status='accepted',driver_lat=NULL,driver_lng=NULL
    WHERE id=p_ride_id AND status='searching' AND driver_id IS NULL;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.set_ride_status_secure(p_ride_id uuid,p_next_status text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_current text;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL OR p_next_status IS NULL THEN RAISE EXCEPTION 'طلب غير صالح'; END IF;
  SELECT r.status INTO v_current FROM public.rides r WHERE r.id=p_ride_id AND r.driver_id=v_uid FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'الرحلة غير موجودة أو لا تخص هذا السائق'; END IF;
  IF NOT ((v_current='accepted' AND p_next_status='arrived') OR
          (v_current='arrived' AND p_next_status='in_progress') OR
          (v_current='in_progress' AND p_next_status='completed')) THEN
    RAISE EXCEPTION 'تغيير حالة الرحلة غير مسموح';
  END IF;
  UPDATE public.rides SET status=p_next_status WHERE id=p_ride_id AND status=v_current AND driver_id=v_uid;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.cancel_searching_ride_secure(p_ride_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_status text; v_rider uuid; v_driver uuid;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL THEN RAISE EXCEPTION 'طلب غير صالح'; END IF;
  SELECT r.status,r.rider_id,r.driver_id INTO v_status,v_rider,v_driver
    FROM public.rides r WHERE r.id=p_ride_id FOR UPDATE;
  IF NOT FOUND OR v_rider IS DISTINCT FROM v_uid OR v_status IS DISTINCT FROM 'searching' OR v_driver IS NOT NULL THEN
    RETURN FALSE;
  END IF;
  UPDATE public.rides SET status='cancelled' WHERE id=p_ride_id AND status='searching' AND rider_id=v_uid AND driver_id IS NULL;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_driver_location_secure(p_ride_id uuid,p_lat double precision,p_lng double precision)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_role text; v_status text;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL THEN RAISE EXCEPTION 'طلب غير صالح'; END IF;
  IF p_lat IS NULL OR p_lat NOT BETWEEN -90 AND 90 OR p_lng IS NULL OR p_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'إحداثيات الموقع غير صحيحة';
  END IF;
  SELECT p.role INTO v_role FROM public.profiles p WHERE p.id=v_uid FOR UPDATE;
  IF NOT FOUND OR v_role IS DISTINCT FROM 'driver' THEN RAISE EXCEPTION 'هذه العملية مخصصة للسائقين'; END IF;
  SELECT r.status INTO v_status FROM public.rides r WHERE r.id=p_ride_id AND r.driver_id=v_uid FOR UPDATE;
  IF NOT FOUND OR v_status NOT IN ('accepted','arrived','in_progress') THEN RETURN FALSE; END IF;
  UPDATE public.rides SET driver_lat=p_lat,driver_lng=p_lng WHERE id=p_ride_id AND driver_id=v_uid AND status=v_status;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.set_driver_online_secure(p_is_online boolean)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_role text; v_verified boolean;
BEGIN
  IF v_uid IS NULL OR p_is_online IS NULL THEN RAISE EXCEPTION 'طلب غير صالح'; END IF;
  SELECT p.role,p.is_verified INTO v_role,v_verified FROM public.profiles p WHERE p.id=v_uid FOR UPDATE;
  IF NOT FOUND OR v_role IS DISTINCT FROM 'driver' THEN RAISE EXCEPTION 'هذه العملية مخصصة للسائقين'; END IF;
  IF p_is_online AND v_verified IS NOT TRUE THEN RAISE EXCEPTION 'يجب اعتماد حساب السائق أولاً'; END IF;
  IF NOT p_is_online AND EXISTS(SELECT 1 FROM public.rides r WHERE r.driver_id=v_uid AND r.status IN ('accepted','arrived','in_progress')) THEN
    RAISE EXCEPTION 'لا يمكن قطع الاتصال أثناء وجود رحلة نشطة';
  END IF;
  UPDATE public.profiles SET is_online=p_is_online WHERE id=v_uid;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.rate_completed_ride_secure(p_ride_id uuid,p_rating smallint)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_status text; v_rider uuid; v_existing smallint;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL OR p_rating IS NULL OR p_rating NOT BETWEEN 1 AND 5 THEN
    RAISE EXCEPTION 'التقييم أو معرف الرحلة غير صالح';
  END IF;
  SELECT r.status,r.rider_id,r.rating INTO v_status,v_rider,v_existing FROM public.rides r WHERE r.id=p_ride_id FOR UPDATE;
  IF NOT FOUND OR v_rider IS DISTINCT FROM v_uid OR v_status IS DISTINCT FROM 'completed' OR v_existing IS NOT NULL THEN
    RAISE EXCEPTION 'لا يمكن تقييم الرحلة أو سبق تقييمها';
  END IF;
  UPDATE public.rides SET rating=p_rating WHERE id=p_ride_id AND rider_id=v_uid AND status='completed' AND rating IS NULL;
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_ride_contact_phone_secure(p_ride_id uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER
SET search_path = '' SET row_security = off
AS $$
DECLARE v_uid uuid:=auth.uid(); v_rider uuid; v_driver uuid; v_status text; v_phone text;
BEGIN
  IF v_uid IS NULL OR p_ride_id IS NULL THEN RAISE EXCEPTION 'طلب غير صالح'; END IF;
  SELECT r.rider_id,r.driver_id,r.status INTO v_rider,v_driver,v_status
    FROM public.rides r WHERE r.id=p_ride_id FOR UPDATE;
  IF NOT FOUND OR v_status NOT IN ('accepted','arrived','in_progress') THEN RAISE EXCEPTION 'بيانات الاتصال غير متاحة'; END IF;
  IF v_uid=v_rider AND v_driver IS NOT NULL THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id=v_driver;
  ELSIF v_uid=v_driver THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id=v_rider;
  ELSE
    RAISE EXCEPTION 'غير مصرح لك بالوصول إلى رقم الهاتف';
  END IF;
  IF v_phone IS NULL OR btrim(v_phone)='' THEN RAISE EXCEPTION 'رقم الهاتف غير متوفر'; END IF;
  RETURN v_phone;
END;
$$;

-- Admin pending-driver list never returns phone.
CREATE OR REPLACE FUNCTION public.admin_list_pending_drivers_secure()
RETURNS TABLE(id uuid,full_name text,is_verified boolean,is_online boolean,car_model text,plate_number text,created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' SET row_security = off
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() THEN RAISE EXCEPTION 'غير مصرح لك بعرض بيانات السائقين'; END IF;
  RETURN QUERY SELECT p.id,p.full_name,p.is_verified,p.is_online,p.car_model,p.plate_number,p.created_at
    FROM public.profiles p WHERE p.role='driver' AND p.is_verified IS FALSE ORDER BY p.created_at DESC;
END;
$$;

-- Admin verification; no ride mutation capability.
CREATE OR REPLACE FUNCTION public.admin_set_driver_verification_secure(p_driver_id uuid,p_verified boolean)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' SET row_security = off
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() OR p_driver_id IS NULL OR p_verified IS NULL THEN
    RAISE EXCEPTION 'غير مصرح أو بيانات غير صالحة';
  END IF;
  PERFORM 1 FROM public.profiles p WHERE p.id=p_driver_id AND p.role='driver' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'السائق غير موجود'; END IF;
  IF NOT p_verified AND EXISTS(SELECT 1 FROM public.rides r WHERE r.driver_id=p_driver_id AND r.status IN ('accepted','arrived','in_progress')) THEN
    RAISE EXCEPTION 'لا يمكن إلغاء اعتماد سائق لديه رحلة نشطة';
  END IF;
  UPDATE public.profiles SET is_verified=p_verified,is_online=CASE WHEN p_verified THEN is_online ELSE FALSE END WHERE id=p_driver_id;
  RETURN FOUND;
END;
$$;

-- ---------------------------------------------------------------------
-- 07. Function execution grants: deny PUBLIC/anon, allow authenticated.
-- ---------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.is_admin_user() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_eligible_driver() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.list_available_rides_secure() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.list_my_rides_secure() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_list_rides_secure() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.create_ride_secure(text,double precision,double precision,text,double precision,double precision) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.accept_ride_secure(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_ride_status_secure(uuid,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.cancel_searching_ride_secure(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_driver_location_secure(uuid,double precision,double precision) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_driver_online_secure(boolean) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.rate_completed_ride_secure(uuid,smallint) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_ride_contact_phone_secure(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_list_pending_drivers_secure() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_set_driver_verification_secure(uuid,boolean) FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.is_admin_user() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_eligible_driver() TO authenticated;
GRANT EXECUTE ON FUNCTION public.list_available_rides_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.list_my_rides_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_rides_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_ride_secure(text,double precision,double precision,text,double precision,double precision) TO authenticated;
GRANT EXECUTE ON FUNCTION public.accept_ride_secure(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_ride_status_secure(uuid,text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_searching_ride_secure(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_driver_location_secure(uuid,double precision,double precision) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_driver_online_secure(boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.rate_completed_ride_secure(uuid,smallint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_ride_contact_phone_secure(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_pending_drivers_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_set_driver_verification_secure(uuid,boolean) TO authenticated;

-- ---------------------------------------------------------------------
-- 08. Postflight: fail transaction if critical ACL/policy/function checks fail.
-- ---------------------------------------------------------------------
DO $postflight$
DECLARE v_count integer;
BEGIN
  IF has_column_privilege('authenticated','public.profiles','phone','SELECT') OR
     has_column_privilege('anon','public.profiles','phone','SELECT') OR
     has_column_privilege('authenticated','public.profiles','role','UPDATE') OR
     has_column_privilege('authenticated','public.profiles','is_verified','UPDATE') OR
     has_column_privilege('authenticated','public.profiles','is_online','UPDATE') THEN
    RAISE EXCEPTION 'Postflight failed: protected profile column privilege remains';
  END IF;
  IF has_table_privilege('authenticated','public.rides','INSERT') OR
     has_table_privilege('authenticated','public.rides','UPDATE') OR
     has_table_privilege('authenticated','public.rides','DELETE') OR
     EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid='public.rides'::regclass AND a.attnum > 0 AND NOT a.attisdropped
       AND (has_column_privilege('authenticated', 'public.rides', a.attname, 'INSERT')
         OR has_column_privilege('authenticated', 'public.rides', a.attname, 'UPDATE'))) THEN
    RAISE EXCEPTION 'Postflight failed: direct rides write privilege remains';
  END IF;
  IF NOT (SELECT c.relrowsecurity FROM pg_class c WHERE c.oid='public.rides'::regclass)
     OR NOT (SELECT c.relrowsecurity FROM pg_class c WHERE c.oid='public.profiles'::regclass) THEN
    RAISE EXCEPTION 'Postflight failed: RLS is not enabled on rides and profiles';
  END IF;
  SELECT count(*) INTO v_count FROM pg_policies WHERE schemaname='public' AND tablename='rides';
  IF v_count <> 1 OR NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='rides' AND policyname='rides_select_participants_admin_v31') THEN
    RAISE EXCEPTION 'Postflight failed: unexpected rides RLS policy inventory';
  END IF;
  SELECT count(*) INTO v_count FROM pg_policies WHERE schemaname='public' AND tablename='profiles';
  IF v_count <> 2 OR NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='profiles' AND policyname='profiles_select_self_related_admin_v31') OR
     NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='profiles' AND policyname='profiles_update_safe_self_v31') THEN
    RAISE EXCEPTION 'Postflight failed: unexpected profiles RLS policy inventory';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND tablename='rides' AND indexname='uq_rides_one_active_trip_per_rider') OR
     NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname='public' AND tablename='rides' AND indexname='uq_rides_one_active_trip_per_driver') THEN
    RAISE EXCEPTION 'Postflight failed: active ride unique indexes missing';
  END IF;
  IF NOT has_function_privilege('authenticated','public.get_ride_contact_phone_secure(uuid)','EXECUTE') OR
     has_function_privilege('anon','public.get_ride_contact_phone_secure(uuid)','EXECUTE') THEN
    RAISE EXCEPTION 'Postflight failed: contact RPC execute grants are incorrect';
  END IF;
  IF NOT has_function_privilege('authenticated','public.list_available_rides_secure()','EXECUTE') THEN
    RAISE EXCEPTION 'Postflight failed: available ride RPC is not executable by authenticated';
  END IF;

  IF EXISTS (
    SELECT 1 FROM (VALUES
      ('public.is_admin_user()'),
      ('public.is_eligible_driver()'),
      ('public.list_my_rides_secure()'),
      ('public.admin_list_rides_secure()'),
      ('public.create_ride_secure(text,double precision,double precision,text,double precision,double precision)'),
      ('public.accept_ride_secure(uuid)'),
      ('public.set_ride_status_secure(uuid,text)'),
      ('public.cancel_searching_ride_secure(uuid)'),
      ('public.update_driver_location_secure(uuid,double precision,double precision)'),
      ('public.set_driver_online_secure(boolean)'),
      ('public.rate_completed_ride_secure(uuid,smallint)'),
      ('public.get_ride_contact_phone_secure(uuid)'),
      ('public.admin_list_pending_drivers_secure()'),
      ('public.admin_set_driver_verification_secure(uuid,boolean)')
    ) AS expected(signature)
    WHERE to_regprocedure(expected.signature) IS NULL
       OR NOT has_function_privilege('authenticated', to_regprocedure(expected.signature), 'EXECUTE')
       OR has_function_privilege('anon', to_regprocedure(expected.signature), 'EXECUTE')
  ) THEN
    RAISE EXCEPTION 'Postflight failed: one or more RPC EXECUTE grants are missing or too broad';
  END IF;
  IF EXISTS (
    SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
    JOIN pg_roles r ON r.oid=p.proowner
    WHERE n.nspname='public' AND p.proname IN (
      'list_available_rides_secure','list_my_rides_secure','admin_list_rides_secure',
      'create_ride_secure','accept_ride_secure','set_ride_status_secure',
      'cancel_searching_ride_secure','update_driver_location_secure',
      'set_driver_online_secure','rate_completed_ride_secure',
      'get_ride_contact_phone_secure','admin_list_pending_drivers_secure',
      'admin_set_driver_verification_secure','is_admin_user','is_eligible_driver'
    ) AND (NOT p.prosecdef OR r.rolname IN ('anon','authenticated','authenticator')
      OR NOT ('search_path=""' = ANY(coalesce(p.proconfig, ARRAY[]::text[])))
      OR NOT ('row_security=off' = ANY(coalesce(p.proconfig, ARRAY[]::text[]))))
  ) THEN RAISE EXCEPTION 'Postflight failed: SECURITY DEFINER ownership is unsafe'; END IF;
END
$postflight$;

COMMIT;
