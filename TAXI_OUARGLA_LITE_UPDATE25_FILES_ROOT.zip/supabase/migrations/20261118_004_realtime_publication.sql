-- TAXI OUARGLA LITE V3.10.1
-- Ensure ride and profile changes are published for the app's live screens.
-- Idempotent: safe to re-run. Does not change business records or permissions.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public' AND tablename = 'rides'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE public.rides;
    END IF;

    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public' AND tablename = 'profiles'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
    END IF;
  ELSE
    RAISE NOTICE 'supabase_realtime publication is not present; enable Supabase Realtime before using live screens.';
  END IF;
END;
$$;
