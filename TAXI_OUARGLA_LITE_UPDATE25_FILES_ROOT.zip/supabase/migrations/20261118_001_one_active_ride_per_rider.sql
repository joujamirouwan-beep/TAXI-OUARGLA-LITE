-- TAXI OUARGLA LITE V3.10.1
-- Existing-database migration: enforce one active ride per rider.
-- Run ONLY after reviewing the read-only audit queries in ../audit/.
-- This migration is intentionally non-destructive: no DROP statements.

BEGIN;

DO $migration$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public.rides
    WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress')
    GROUP BY rider_id
    HAVING COUNT(*) > 1
  ) THEN
    RAISE EXCEPTION USING
      ERRCODE = '23505',
      MESSAGE = 'Migration stopped: duplicate active rides exist for one or more riders. Resolve duplicates manually after reviewing the affected rows.';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM pg_catalog.pg_class c
    JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public'
      AND c.relname = 'rides_one_active_per_rider_v1'
  ) THEN
    RAISE EXCEPTION USING
      ERRCODE = '42710',
      MESSAGE = 'Index name rides_one_active_per_rider_v1 already exists. Inspect its definition; this migration will not replace it.';
  END IF;
END;
$migration$;

CREATE UNIQUE INDEX rides_one_active_per_rider_v1
  ON public.rides (rider_id)
  WHERE status IN ('searching', 'accepted', 'arrived', 'in_progress');

COMMIT;
