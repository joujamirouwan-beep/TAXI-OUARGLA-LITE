-- Existing-project migration: protect profile phone numbers.
-- Review the current grants and policies before applying to production.
BEGIN;

REVOKE ALL ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
REVOKE SELECT (phone) ON TABLE public.profiles FROM PUBLIC, anon, authenticated;
REVOKE ALL ON TABLE public.rides FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.rides TO authenticated;
REVOKE INSERT (rider_id, pickup_address, pickup_lat, pickup_lng,
  dropoff_address, dropoff_lat, dropoff_lng)
  ON TABLE public.rides FROM PUBLIC, anon, authenticated;
REVOKE UPDATE (driver_id, status, driver_lat, driver_lng, rating)
  ON TABLE public.rides FROM PUBLIC, anon, authenticated;
DROP POLICY IF EXISTS rides_create_own_search_request ON public.rides;
GRANT SELECT (
  id, full_name, role, is_verified, is_online,
  car_model, plate_number, created_at, updated_at
) ON TABLE public.profiles TO authenticated;
GRANT UPDATE (full_name, car_model, plate_number)
  ON TABLE public.profiles TO authenticated;


CREATE OR REPLACE FUNCTION public.create_ride_secure(
  p_pickup_address TEXT,
  p_pickup_lat DOUBLE PRECISION,
  p_pickup_lng DOUBLE PRECISION,
  p_dropoff_address TEXT,
  p_dropoff_lat DOUBLE PRECISION,
  p_dropoff_lng DOUBLE PRECISION
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_role TEXT;
  v_ride public.rides%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'يجب تسجيل الدخول أولاً'; END IF;
  IF p_pickup_address IS NULL OR char_length(btrim(p_pickup_address)) NOT BETWEEN 2 AND 300
     OR p_dropoff_address IS NULL OR char_length(btrim(p_dropoff_address)) NOT BETWEEN 2 AND 300 THEN
    RAISE EXCEPTION 'يرجى إدخال عنوان صحيح للانطلاق والوجهة';
  END IF;
  IF p_pickup_lat IS NULL OR p_pickup_lat NOT BETWEEN -90 AND 90
     OR p_pickup_lng IS NULL OR p_pickup_lng NOT BETWEEN -180 AND 180
     OR p_dropoff_lat IS NULL OR p_dropoff_lat NOT BETWEEN -90 AND 90
     OR p_dropoff_lng IS NULL OR p_dropoff_lng NOT BETWEEN -180 AND 180 THEN
    RAISE EXCEPTION 'إحداثيات الموقع غير صحيحة';
  END IF;
  SELECT p.role INTO v_role FROM public.profiles p WHERE p.id = v_uid FOR UPDATE;
  IF NOT FOUND OR v_role <> 'rider' THEN RAISE EXCEPTION 'إنشاء طلب الرحلة متاح للركاب فقط'; END IF;
  IF EXISTS (SELECT 1 FROM public.rides r WHERE r.rider_id = v_uid
    AND r.status IN ('searching', 'accepted', 'arrived', 'in_progress')) THEN
    RAISE EXCEPTION 'لديك طلب رحلة نشط بالفعل';
  END IF;
  INSERT INTO public.rides (rider_id, pickup_address, pickup_lat, pickup_lng,
    dropoff_address, dropoff_lat, dropoff_lng)
  VALUES (v_uid, btrim(p_pickup_address), p_pickup_lat, p_pickup_lng,
    btrim(p_dropoff_address), p_dropoff_lat, p_dropoff_lng)
  RETURNING * INTO v_ride;
  RETURN jsonb_build_object('id', v_ride.id, 'status', v_ride.status,
    'created_at', v_ride.created_at);
END;
$$;

REVOKE ALL ON FUNCTION public.create_ride_secure(TEXT, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION, DOUBLE PRECISION) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_ride_secure(TEXT, DOUBLE PRECISION, DOUBLE PRECISION, TEXT, DOUBLE PRECISION, DOUBLE PRECISION) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_list_pending_drivers_secure()
RETURNS TABLE (
  id UUID,
  full_name TEXT,
  is_verified BOOLEAN,
  is_online BOOLEAN,
  car_model TEXT,
  plate_number TEXT,
  created_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_admin_user() THEN
    RAISE EXCEPTION 'غير مصرح لك بعرض بيانات السائقين';
  END IF;

  RETURN QUERY
  SELECT p.id, p.full_name, p.is_verified, p.is_online,
         p.car_model, p.plate_number, p.created_at
  FROM public.profiles p
  WHERE p.role = 'driver' AND p.is_verified IS FALSE
  ORDER BY p.created_at DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_ride_contact_phone_secure(p_ride_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_uid UUID := auth.uid();
  v_rider UUID;
  v_driver UUID;
  v_status TEXT;
  v_phone TEXT;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'يجب تسجيل الدخول أولاً';
  END IF;

  SELECT r.rider_id, r.driver_id, r.status
  INTO v_rider, v_driver, v_status
  FROM public.rides r
  WHERE r.id = p_ride_id
  FOR UPDATE;

  IF NOT FOUND OR v_status NOT IN ('accepted', 'arrived', 'in_progress') THEN
    RAISE EXCEPTION 'بيانات الاتصال غير متاحة لهذه الرحلة';
  END IF;

  IF v_uid = v_rider AND v_driver IS NOT NULL THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id = v_driver;
  ELSIF v_uid = v_driver THEN
    SELECT p.phone INTO v_phone FROM public.profiles p WHERE p.id = v_rider;
  ELSE
    RAISE EXCEPTION 'غير مصرح لك بالوصول إلى رقم الهاتف';
  END IF;

  IF v_phone IS NULL OR btrim(v_phone) = '' THEN
    RAISE EXCEPTION 'رقم الهاتف غير متوفر';
  END IF;
  RETURN v_phone;
END;
$$;

REVOKE ALL ON FUNCTION public.admin_list_pending_drivers_secure() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.get_ride_contact_phone_secure(UUID) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_list_pending_drivers_secure() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_ride_contact_phone_secure(UUID) TO authenticated;

COMMIT;
