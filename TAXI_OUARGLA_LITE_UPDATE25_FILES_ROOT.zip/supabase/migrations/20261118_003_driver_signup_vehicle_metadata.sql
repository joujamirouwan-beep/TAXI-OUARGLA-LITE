-- Preserve vehicle details supplied by a new driver during phone OTP signup.
-- Safe for an existing V2/V2.1 database: replaces only the auth profile trigger function.
-- Public signup can create rider/driver profiles only; admin remains manual.

BEGIN;

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_name TEXT;
  v_role TEXT;
  v_car_model TEXT;
  v_plate_number TEXT;
BEGIN
  v_name := COALESCE(
    NULLIF(btrim(NEW.raw_user_meta_data ->> 'full_name'), ''),
    'مستخدم جديد'
  );

  v_role := CASE
    WHEN NEW.raw_user_meta_data ->> 'role' = 'driver' THEN 'driver'
    ELSE 'rider'
  END;

  v_car_model := NULLIF(btrim(NEW.raw_user_meta_data ->> 'car_model'), '');
  v_plate_number := NULLIF(btrim(NEW.raw_user_meta_data ->> 'plate_number'), '');

  INSERT INTO public.profiles (
    id, full_name, phone, role, car_model, plate_number
  )
  VALUES (
    NEW.id,
    v_name,
    NULLIF(NEW.phone, ''),
    v_role,
    CASE WHEN v_role = 'driver' THEN v_car_model ELSE NULL END,
    CASE WHEN v_role = 'driver' THEN v_plate_number ELSE NULL END
  );

  RETURN NEW;
END;
$$;

COMMIT;
