-- TAXI OUARGLA LITE: durable in-app notifications (no FCM credentials required).
-- Apply only after the existing rides/profiles schema and migration 006 are verified.
BEGIN;

CREATE TABLE IF NOT EXISTS public.user_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ride_id uuid NULL REFERENCES public.rides(id) ON DELETE SET NULL,
  event_key text NOT NULL CHECK (event_key IN (
    'new_request', 'ride_accepted', 'driver_arrived', 'ride_started',
    'ride_completed', 'ride_cancelled'
  )),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 120),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz NULL,
  CONSTRAINT user_notifications_user_ride_event_uq UNIQUE (user_id, ride_id, event_key)
);

CREATE INDEX IF NOT EXISTS user_notifications_user_created_idx
  ON public.user_notifications (user_id, created_at DESC);

ALTER TABLE public.user_notifications ENABLE ROW LEVEL SECURITY;
DO $drop_notification_policies$
DECLARE p record;
BEGIN
  FOR p IN
    SELECT policyname FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'user_notifications'
  LOOP
    EXECUTE format('DROP POLICY %I ON public.user_notifications', p.policyname);
  END LOOP;
END
$drop_notification_policies$;
CREATE POLICY user_notifications_read_own
  ON public.user_notifications FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY user_notifications_mark_own_read
  ON public.user_notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

REVOKE ALL ON TABLE public.user_notifications FROM PUBLIC, anon, authenticated;
REVOKE ALL (id, user_id, ride_id, event_key, title, body, created_at, read_at)
  ON TABLE public.user_notifications FROM PUBLIC, anon, authenticated;
GRANT SELECT ON TABLE public.user_notifications TO authenticated;
GRANT UPDATE (read_at) ON TABLE public.user_notifications TO authenticated;

CREATE OR REPLACE FUNCTION public.create_ride_notifications_v1()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
SET row_security = off
AS $function$
DECLARE
  v_title text;
  v_body text;
  v_event text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status = 'searching' THEN
      INSERT INTO public.user_notifications (user_id, ride_id, event_key, title, body)
      SELECT p.id, NEW.id, 'new_request', 'طلب رحلة جديد',
             'يوجد طلب رحلة جديد متاح في ورقلة.'
      FROM public.profiles p
      WHERE p.role = 'driver' AND p.is_verified IS TRUE AND p.is_online IS TRUE
        AND p.id IS DISTINCT FROM NEW.rider_id
        -- Do not alert drivers who already have an assigned active ride.
        AND NOT EXISTS (
          SELECT 1 FROM public.rides active_ride
          WHERE active_ride.driver_id = p.id
            AND active_ride.status IN ('accepted', 'arrived', 'in_progress')
        )
      ON CONFLICT (user_id, ride_id, event_key) DO NOTHING;
    END IF;
    RETURN NEW;
  END IF;

  IF OLD.status IS NOT DISTINCT FROM NEW.status THEN
    RETURN NEW;
  END IF;

  CASE NEW.status
    WHEN 'accepted' THEN
      v_event := 'ride_accepted';
      v_title := 'تم قبول طلبك';
      v_body := 'وافق سائق على طلب الرحلة. يمكنك متابعة حالة الرحلة من التطبيق.';
    WHEN 'arrived' THEN
      v_event := 'driver_arrived';
      v_title := 'وصل السائق';
      v_body := 'وصل السائق إلى نقطة الانطلاق.';
    WHEN 'in_progress' THEN
      v_event := 'ride_started';
      v_title := 'بدأت الرحلة';
      v_body := 'تم تحديث حالة رحلتك إلى: قيد التنفيذ.';
    WHEN 'completed' THEN
      v_event := 'ride_completed';
      v_title := 'اكتملت الرحلة';
      v_body := 'اكتملت رحلتك. يمكنك تقييم الرحلة من التطبيق.';
    WHEN 'cancelled' THEN
      v_event := 'ride_cancelled';
      v_title := 'تم إلغاء الرحلة';
      v_body := 'تم إلغاء طلب الرحلة.';
    ELSE
      RETURN NEW;
  END CASE;

  -- Status changes are announced to the rider. A cancellation after assignment
  -- is also announced to the assigned driver; searching cancellation has none.
  INSERT INTO public.user_notifications (user_id, ride_id, event_key, title, body)
  VALUES (NEW.rider_id, NEW.id, v_event, v_title, v_body)
  ON CONFLICT (user_id, ride_id, event_key) DO NOTHING;

  IF NEW.status = 'cancelled' AND NEW.driver_id IS NOT NULL THEN
    INSERT INTO public.user_notifications (user_id, ride_id, event_key, title, body)
    VALUES (NEW.driver_id, NEW.id, v_event, v_title, v_body)
    ON CONFLICT (user_id, ride_id, event_key) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$function$;

REVOKE ALL ON FUNCTION public.create_ride_notifications_v1() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS rides_create_notifications_v1 ON public.rides;
CREATE TRIGGER rides_create_notifications_v1
AFTER INSERT OR UPDATE OF status ON public.rides
FOR EACH ROW EXECUTE FUNCTION public.create_ride_notifications_v1();

COMMIT;
