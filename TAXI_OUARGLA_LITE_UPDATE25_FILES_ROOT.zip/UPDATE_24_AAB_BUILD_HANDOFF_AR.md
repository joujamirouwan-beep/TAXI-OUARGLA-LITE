# UPDATE 24 — بوابة بناء AAB وتسليمه للمبرمج

## الحالة الصادقة
هذه الحزمة تحتوي مصدر Flutter وإعدادات بناء وفحوصاً مسبقة. **لم يتم إنشاء AAB في بيئة إعداد هذه الحزمة** لأن Flutter/Dart وJDK/Gradle وملفات Gradle Wrapper ومفتاح التوقيع الأصلي غير متاحة هنا. لا ترفع ZIP المصدر على أنه AAB.

## إعداد Android المثبت في المصدر
- `applicationId` و`namespace`: `com.taxiouargla.lite` (يمنع تغييره).
- Android Gradle Plugin: `8.3.2`.
- Kotlin Gradle Plugin: `1.9.22`.
- Gradle distribution المحدد: `8.4`.
- يلزم JDK 17.
- Flutter SDK متوافق مع Dart constraint في `pubspec.yaml` (`>=3.3.0 <4.0.0`).
- الإصدار الافتراضي بالمصدر: `3.10.1+31001`. إعداد Android يستخدم `flutter.versionCode` و`flutter.versionName` كي يتحكم `--build-number` و`--build-name` في بيانات الإصدار. يجب أن يكون BUILD_NUMBER أعلى من آخر versionCode منشور فعلياً في Play Console؛ لا تعتمد 31002 قبل التحقق.

## ما يجب استعادته من بيئة المبرمج الأصلية
1. `android/gradlew` و`android/gradlew.bat` و`android/gradle/wrapper/gradle-wrapper.jar` من مشروع Flutter الأصلي المتوافق مع Gradle 8.4، أو توليدها محلياً بأداة موثوقة بعد مراجعة التوافق.
2. مفتاح الرفع/التوقيع الأصلي المرتبط بسجل التطبيق في Google Play، مع `android/key.properties` محلياً. لا ترسل keystore أو كلمات المرور عبر واتساب.
3. `android/local.properties` الذي يشير إلى Flutter SDK المحلي. هذا الملف لا يرسل ضمن ZIP.
4. `SUPABASE_URL` و`SUPABASE_ANON_KEY` فقط. يمنع تماماً تضمين `service_role` key في تطبيق الهاتف.

## أمر البناء — Linux/macOS
```bash
export SUPABASE_URL='https://PROJECT.supabase.co'
export SUPABASE_ANON_KEY='PUBLIC_ANON_OR_PUBLISHABLE_KEY'
export BUILD_NUMBER='رقم_أعلى_من_آخر_إصدار_في_Play_Console'
./tools/build_release_aab.sh
```

## أمر البناء — Windows PowerShell
```powershell
$env:SUPABASE_URL = 'https://PROJECT.supabase.co'
$env:SUPABASE_ANON_KEY = 'PUBLIC_ANON_OR_PUBLISHABLE_KEY'
$env:BUILD_NUMBER = 'رقم_أعلى_من_آخر_إصدار_في_Play_Console'
.\tools\BUILD_AAB_WINDOWS.ps1
```

قبل التشغيل، يجب إنشاء `android/key.properties` محلياً اعتماداً على `android/key.properties.example`، وتحديد `storeFile` إلى ملف keystore الأصلي. لا تضع الأسرار في مستودع Git.

## تسلسل بوابة الإصدار
1. `python tools/update_24_android_preflight.py` — فحص متطلبات Android الساكنة.
2. `flutter doctor -v` و`java -version` — تحقق من الأدوات.
3. `flutter pub get`.
4. `dart format lib test`.
5. `flutter analyze`.
6. `flutter test`.
7. نفّذ سكربت البناء أعلاه.
8. تحقق من وجود `build/app/outputs/bundle/release/app-release.aab`، وافحص سلامة ZIP وتوقيع AAB وSHA-256.
9. افتح AAB في Google Play Console / Internal testing، ثم اختبر التطبيق على جهاز فعلي قبل أي طرح عام.

## مخرجات التسليم التي يجب أن يعيدها المبرمج
- ملف `app-release.aab` الناتج فعلياً.
- SHA-256 للملف.
- مخرجات `flutter analyze` و`flutter test` دون أخطاء مانعة.
- تأكيد `applicationId` و`versionCode` ونجاح التوقيع.
- نتيجة اختبار داخلي لتسجيل الدخول والرحلات والإشعارات والموقع.

## قرار النشر
الحالة الآن **NO-GO** حتى توفر متطلبات البناء والتوقيع، نجاح التحليل والاختبارات، إنتاج AAB موقّع بالمفتاح الأصلي، وتجربة النسخة على أجهزة فعلية. هذا الملف خطة تنفيذ وليس شهادة نجاح بناء.

## ملاحظة بيئة الفحص التي أُجري فيها إعداد UPDATE 24
المتاح هنا Java 21 وليس JDK 17، كما لا يوجد Flutter SDK أو Gradle Wrapper أو ملف التوقيع المحلي. وبما أن المشروع مثبت على Gradle 8.4 مع AGP 8.3.2، فقد أُبقيت نسخة Gradle كما هي ولم أرفعها عشوائياً؛ استخدم JDK 17 على جهاز البناء. فحص UPDATE 24 يعرض هذه المتطلبات كـ BLOCK بدلاً من تمريرها شكلياً.
