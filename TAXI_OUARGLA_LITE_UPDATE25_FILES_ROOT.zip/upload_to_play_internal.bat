@echo off
setlocal
cd /d "%~dp0"
if "%EXPECTED_UPLOAD_CERT_SHA256%"=="" (
  echo ERROR: Set EXPECTED_UPLOAD_CERT_SHA256 to the upload certificate SHA-256 shown in Play Console.
  exit /b 2
)
if not exist "play-api-key.json" (
  echo ERROR: play-api-key.json is missing. Download the service-account JSON securely and keep it local.
  exit /b 2
)
if not exist "build\app\outputs\bundle\release\app-release.aab" (
  echo ERROR: app-release.aab is missing. Build the signed AAB first.
  exit /b 2
)
python -m pip install -r tools\requirements-play-upload.txt
if errorlevel 1 exit /b 1
python tools\upload_to_play_internal.py --aab build\app\outputs\bundle\release\app-release.aab --package com.taxiouargla.lite --track internal --service-account play-api-key.json
if errorlevel 1 exit /b 1
echo Upload edit committed as DRAFT. Verify versionCode in output, then run:
echo python tools\verify_upload.py --version-code VERSION_CODE --expected-status draft
endlocal
